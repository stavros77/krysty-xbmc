import os, hashlib, re, traceback
from resources.lib.net import Net
from resources.lib import resolvers
from resources.lib.parsedom import parseDOM
import common, utils, log_utils


CACHE_ENABLE = common.addon.getSetting('enableCache') == 'true'
CACHE_EXPIRE = int(common.addon.getSetting('cacheExpire'))

net = Net()

def urlFilter(url):
	if isinstance(url, unicode):
		url = url.encode('utf-8')
	if not url == '':
		if url.startswith('/'):
			url = url[1:]
		if not url.startswith(common.URLS['base']):
			url = common.URLS['base'] + url
	return url


def cache(url, action, type, data=None, param=None):
    filename = url + type
    if param:
        filename += param
    filename = hashlib.md5(filename).hexdigest()
    filepath = os.path.join(common.cache_path, filename)
    
    if action == 'save':
        utils.save_to_cache(type, data, filepath)
        return
    
    elif action == 'load':
        return utils.load_from_cache(type, filepath, CACHE_EXPIRE)

def format_year(str_year):
    year = {'start': '', 'end': '', 'start_end': ''}

    str_year = str_year.replace('(', '').replace(')', '').strip()

    m = re.search(r'(\d{4})-?(\d{4})?', str_year)
    if m:
        year['start'] = m.group(1)
        
        end_year = m.group(2)
        if end_year:
            year['end'] = end_year
        
        year['start_end'] = '%s-%s'% (year['start'], year['end'])

    for k, v in year.items():
        if isinstance(v, unicode):
            year[k] = v.encode('utf-8')

    return year

def _getHtml(url):
    html = ''
    
    if CACHE_ENABLE:
        html = cache(url, 'load', 'string')
    
    if not html:
        html = net.http_GET(url, common.HEADERS).content
        
        if html and CACHE_ENABLE:
            cache(url, 'save', 'string', html)
    
    return html


def _extract_html_div(html, div_start_string):
    try:
        m = re.search(div_start_string, html, re.DOTALL)
        
        html = html[m.start():]

        div = ''

        i = 0
        for line in html.splitlines():
            div += line.strip()
            m = re.findall(r'<div', line)
            n = re.findall(r'<\/div>', line)
            i += len(m)
            i -= len(n)
            if i == 0:
                break
        
        return div
    
    except:
        log_utils.log(traceback.print_exc())
        return None


def _ro2en(string):
	dict = {
			'Actiune':		'Action',
			'Animatie':		'Animation',
			'Aventura':		'Adventure',
			'Biografie':	'Biography',
			'Comedie':		'Comedy',
			'Crima':		'Crime',
			'Documentar':	'Documentary',
			'Dragoste':		'Romance',
			'Familie':		'Family',
			'Fantezie':		'Fantasy',
			'Istorie':		'History',
			'Mafie':		'Mafia',
			'Mister':		'Mystery',
			'Razboi':		'War',
			'Sarbatori':	'Holidays',
			'SF':			'Sci-Fi'
	}
	string = string.strip()
	
	if string in dict:
		return dict[string]
	
	return string


def _parseTVShows(html, filter=None):
    tvshows = [] 
    
    try:
        div = parseDOM(html, 'div', attrs={'id': 'tab1'})[0]
        
        if not filter:
            filter = '(.+?)'
        else:
            filter = '(%s.*?)' % (filter)
        
        regex = r"<a href='(.+?)' class='link'>%s<\/a>(.+?)<br\/?>" % (filter)
        
        results = re.findall(regex, div, re.IGNORECASE)
        
        for link, name, year in results:
            tvshow = {}
            tvshow['name'] = utils.unescape(name, True)
            tvshow['url'] = urlFilter(link)
            tvshow['year'] = format_year(year)['start']
            tvshows.append(tvshow)
            
    except:
        log_utils.log(traceback.print_exc())

    return tvshows
    

def _parseEpisodes(html, season):
    episodes = []

    try:
        div = parseDOM(html, 'div', attrs={'id': 'content'})[0]
        
        lst = re.split(r"<img.+?alt='Sezonul \d+'", div)
        lst.pop(0)
        
        soup = common.initBeautifulSoup(lst[int(season)-1])
        
        a_tags = soup.findAll('a', href=re.compile('seriale2'))
        
        for a in a_tags:
            n = a.parent.parent.div.text
            m = re.search(r'Sezonul \d+, Episodul (\d+)', n)
            ep_num = m.group(1) if m else ''           
            ep_name = utils.unescape(a.text, True)
            if re.search(r'Episodul [\d-]+', ep_name):
                ep_name = ''

            episode = {}
            episode['url'] = urlFilter(a['href'])
            episode['season'] = season
            episode['episode'] = ep_num
            episode['name'] = ep_name
            episodes.append(episode)

    except:
        log_utils.log(traceback.print_exc())

    return episodes


def _parseMovies(html):
    movies = []

    try:
        results = re.findall(r"<a href='(filme.+?)'.+? class='link'>(.+?)</a>.+?Aparitie:\s?(.+?)Gen", html, re.DOTALL)
        
        for url, name, year in results:
            m = re.search(r'(\d{4})', year)
            year = m.group(1).encode('utf-8') if m else ''
            
            movie = {}
            movie['url'] = urlFilter(url)
            movie['name'] = utils.unescape(name, True)
            movie['year'] = year
            
            movies.append(movie)

    except:
        log_utils.log(traceback.print_exc())

    return movies


def _get(url, type, param=None):
    lst = []

    if CACHE_ENABLE:
        cache_data = cache(url, 'load', 'json', param=param)
        
        if cache_data:
            lst = cache_data

    if not lst:
        html = _getHtml(url)
        
        if type == 'tvshows':
            lst = _parseTVShows(html, param)
        
        elif type == 'episodes':
            lst = _parseEpisodes(html, param)
        
        elif type == 'movies':
            lst = _parseMovies(html)
        
        if lst and CACHE_ENABLE:
            cache(url, 'save', 'json', lst, param)

    return lst


def getTVShows(filter=False):
    return _get(common.URLS['tvshows'], 'tvshows', filter)


def getSeasons(url):
    html = _getHtml(url)
    
    m = re.findall(r"<img src='.+?' alt='Sezonul (\d+)'>", html)
    
    return len(m)


def getEpisodes(url, season):
    return _get(url, 'episodes', season)


def getMovies(url):
    return _get(url, 'movies')


def getRecentlyAdded(category, resultsLimit):
    lst = []

    try:
        html = net.http_GET(common.URLS['base'], common.HEADERS).content
        
        div = parseDOM(html, 'div', attrs={'id': 'tab1'})

        if category == 'episodes':
            div = div[0]
            param = 'seriale'

        elif category == 'movies':
            div = div[1]
            param = 'filme'
        
        soup = common.initBeautifulSoup(div)
        results = soup.findAll('a', href=re.compile(param), limit=resultsLimit)
        
        for a in results:
            ep_year = a.parent.parent.findAll('div')[1].text.strip()
            
            item = {}
            item['name'] = utils.unescape(a.text, True)
            item['url'] = urlFilter(a['href'])
            
            if category == 'episodes':
                eps = re.search(r'S(\d+)E(\d+-?\d*)', ep_year)
                
                season = eps.group(1) if eps else ''
                episode = eps.group(2) if eps else ''
                
                item['season'] = season
                item['episode'] = episode
            
            elif category == 'movies':
                item['year'] = ep_year
            
            lst.append(item)

    except:
        log_utils.log(traceback.print_exc())

    return lst


def getTotalPages(url):
    pages = 1
    try:
        html = _getHtml(url)
        r = parseDOM(html, 'div', attrs={'id': 'numarpagini'})[0]
        r = re.findall(r'<a .+?>(\d+)</a>', r)
        r = [int(x) for x in r if x.isdigit()]
        if r:
            pages = max(r)
    except:
        log_utils.log(traceback.print_exc())
    return pages


def getVideoCategories(type):
    categories = []

    try:
        url = common.URLS['movies']
        
        html = _getHtml(url)
        
        ret = parseDOM(html, 'div', attrs={'id': 'filtre'})
        
        if type == 'year':
            n = parseDOM(ret[1], 'a')
            u = parseDOM(ret[1], 'a', ret='href')
        
        elif type == 'genre':
            n = parseDOM(ret[0], 'a')
            u = parseDOM(ret[0], 'a', ret='href')
        
        if (len(n) == len(u)):
            if n[0] == 'Toate':
                n.pop(0)
                u.pop(0)
            for i in range(len(n)):
                name = n[i]
                link = utils.unescape(u[i])
                if link[-1] == "'":
                    link = link[:-1]
                if url not in link:
                    link = url + link
                if type == 'genre':
                    name = _ro2en(n[i])
                
                category = {}
                category['name'] = name
                category['url'] = link
                categories.append(category)
    
    except:
        log_utils.log(traceback.print_exc())

    return categories


def getStreamSourceMirrors(url):
    sources = []

    try:
        html = _getHtml(url)
        m = re.findall(r"<a class='link' href='(player.+?)'", html)
        
        links = []
        for a in m:
            if a not in links:
                links.append(a)
        
        all_sources = []
        for link in links:
            link = urlFilter(link)
            
            try:
                html = _getHtml(link)
                playerdiv = _extract_html_div(html, r"<div class='player.+?'")
                link = parseDOM(playerdiv, 'a', ret='href')[0]
                link = link[link.rfind('http'):]
                if 'mastervid' in link:
                    html = _getHtml(link)
                    iframe_sources = parseDOM(html, 'iframe', ret='src')
                    for src in iframe_sources:
                        all_sources.append(src)
                else:
                    all_sources.append(link)
            except:
                log_utils.log(traceback.print_exc())
        
        known_hosts = []
        for source in all_sources:
            netloc = resolvers.get_netloc(source)
            if resolvers.known_host(netloc):
                url = resolvers.get_embed_url(source)
                if url not in known_hosts:
                    known_hosts.append(url)
                    sources.append({'host': netloc, 'url': url})
    except:
        log_utils.log(traceback.print_exc())
    
    return sources


def getMovieQuality(url):
    try:
        html = _getHtml(url)

        if re.search('filme', url):
            n = re.search(r'Calitate film: nota <b>(.+?)</b>', html)
            if n:
                return n.group(1)
    except:
        log_utils.log(traceback.print_exc())
        return ''


def getSearchResults(text, category='all'):
    results = []

    try:
        html = net.http_POST(common.URLS['search'], {'kw': text}, common.HEADERS).content

        if category == 'tvshows':
            param = 'seriale'

        elif category == 'movies':
            param = 'filme'

        if category == 'all':
            m = re.findall(r"<a href='(.+?)'.+?id='rest'>(.+?)<div", html)
        else:
            m = re.findall(r"<a href='(" + param + ".+?)'.+?id='rest'>(.+?)<div", html)

        for link, name in m:
            r = re.compile(r'\(.+?\)')
            n = r.search(name)
            
            name = re.sub(r, '', name).strip()
            year = format_year(n.group(0))['start'] if n else ''
            
            if re.search(r'seriale', link):
                type = 'tvshow'
            
            elif re.search(r'filme', link):
                type = 'movie'
            
            item = {}
            item['type'] = type
            item['name'] = utils.unescape(name, True)
            item['year'] = year
            item['url'] = urlFilter(link)
            results.append(item)

    except:
        log_utils.log(traceback.print_exc())

    return results
