import re
from ..net import Net
from .. import jsunpack


def get_embed_url(url):
    ids = re.search(r'https?://(?:www.)?xvidstage.com/([0-9A-Za-z]+)', url)
    if ids:
        return 'http://www.xvidstage.com/embed-%s.html' % ids.group(1)
    return url


def resolve(url):
    url = get_embed_url(url)
    
    html = Net().http_GET(url).content

    match = re.findall(r'(eval.*?\)\)\))', html)
    
    if match:
        jsUnpacked = jsunpack.unpack(match[-1])
        r = re.search(r"\\'file\\',\\'(.+?)\\'", jsUnpacked)
        if r:
            return r.group(1)
