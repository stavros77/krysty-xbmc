import sys, os
import xbmc, xbmcaddon
from resources.lib.bs4 import BeautifulSoup

URLS = {
    'base':     'http://89.40.16.50/',
    'search':   'http://89.40.16.50/functions/search3/live_search_using_jquery_ajax/search.php',
    'tvshows':  'http://89.40.16.50/seriale.php',
    'movies':   'http://89.40.16.50/toate-filmele.php'
}

ICONS = {
	'tvshows':	'tvshowsicon.png',
	'movies':	'moviesicon.png',
	'search':	'searchicon.png',
	'settings':	'settingsicon.png'
}

HEADERS = {
	'User-Agent': 	 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
	'Accept': 		 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Cache-Control': 'no-transform'
}

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_version = addon.getAddonInfo('version')
addon_path = xbmc.translatePath(addon.getAddonInfo('path'))
profile_path = xbmc.translatePath(addon.getAddonInfo('profile'))
cache_path = os.path.join(profile_path, 'cache')
addon_fullname = '%s v%s' % (addon_id, addon_version)

for folder in [profile_path, cache_path]:
    if not os.path.exists(folder):
        os.makedirs(folder)

for icon in ICONS:
	ICONS[icon] = os.path.join(addon_path, 'resources', 'media', ICONS[icon])

def getSetting(settingId):
	return addon.getSetting(settingId)

def notify(message,duration=3000):
    title = addon_id + ' Notification'
    icon = os.path.join(addon_path, 'resources', 'media', 'inficon.png')
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (title, message, duration, icon))

def initBeautifulSoup(html):
    return BeautifulSoup(html, 'html5lib')
