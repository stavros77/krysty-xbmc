import re, urlparse, urllib, urllib2
from ..net import Net
from ..parsedom import parseDOM
from .. import jsunpack


def get_embed_url(url):
    return url


def resolve(url):
    q = urlparse.urlparse(url).query
    q = urlparse.parse_qsl(url)[0][1]
    url = 'http://videomega.tv/cdn.php?ref=%s' % q
    
    headers = {
        'User-Agent': Net.ANDROID_USER_AGENT,
        'Referer': url
    }
    
    html = Net().http_GET(url, headers=headers).content
    
    subtitles = []
    
    try:
        subtitles = re.findall(r'<track kind="captions" src="(.+?)" .+? label="(.+?)" .+?>', html)
    except:
        pass
    
    if jsunpack.detect(html):
        html = jsunpack.unpack(html)
    
    video_url = re.search('"src"\s*,\s*"([^"]+)', html).group(1)
    
    r = urllib2.Request(video_url, headers=headers)
    r = int(urllib2.urlopen(r, timeout=15).headers['Content-Length'])

    if r > 1048576:
        video_url = video_url + '|' + urllib.urlencode(headers)
    
    return [video_url, subtitles]
