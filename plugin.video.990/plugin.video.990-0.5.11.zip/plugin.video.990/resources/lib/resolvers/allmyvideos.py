import re, json
from ..net import Net


def get_embed_url(url):
    u = url.replace('/embed-', '/')
    ids = re.findall('//.+?/([\w]+)', u)
    if ids:
        return 'http://allmyvideos.net/%s' % ids[0]


def resolve(url):
    url = get_embed_url(url)
    
    net = Net()
    
    response = net.http_GET(url, {'Referer': url})
    html = response.content
    
    form_values = {}
    for s in re.finditer(r'<input type="hidden" name="(.+?)" value="(.+?)">', html):
        form_values[s.group(1)] = s.group(2)
    
    html = net.http_POST(response.get_url(), form_values).content
    
    jw_conf = re.search(r'jwConfig\((.+?)\)', html, re.DOTALL).group(1)
    jw_conf = jw_conf.replace('\n', '')
    
    jw_conf = json.loads(jw_conf)
    
    videos = []
    for source in jw_conf['playlist'][0]['sources']:
        if source['label'][-1] != 'p':
            source['label'] += 'p'
        u = source['file'] + '&direct=false&ua=false'
        videos.append([u, source['label']])
    
    return [videos, None]
