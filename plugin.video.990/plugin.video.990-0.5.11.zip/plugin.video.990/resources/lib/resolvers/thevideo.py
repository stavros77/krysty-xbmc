import re, json
from ..net import Net


def get_embed_url(url):
    u = url.replace('/embed-', '/').replace('/download', '/')
    ids = re.findall(r'//.+?/([\w]+)', u)
    if ids:
        return 'http://thevideo.me/embed-%s.html' % ids[0]
    return url


def resolve(url):
    url = get_embed_url(url)
    
    html = Net().http_GET(url).content
    html = html.replace('\n', '')
    
    video_sources = re.findall(r'sources *: *(\[.+?\])', html)[-1]
    video_sources = re.findall(r'label *: *[\'|\"](.+?)[\'|\"], file *: *[\'|\"](.+?)[\'|\"]', video_sources)
    
    videos = []
    subtitles = []
    
    for video in video_sources:
        videos.append([video[1], video[0]])
    
    try:
        tracks = re.findall(r'tracks *: *(\[.+?\])', html)[-1]
        tracks = re.sub(r'([\{\s,])(\w+)(:)', r'\1"\2"\3', tracks)
        tracks = json.loads(tracks)
        
        for track in tracks:
            if 'captions' in track['kind']:
                subtitle = (track['file'], track['label'])
                subtitles.append(subtitle)
    except:
        pass
    
    return [videos, subtitles]
