import urllib, urllib2, json
from ..net import Net
from ..jsinterp import JSInterpreter


VIDEO_ENCODING = {
    # Flash
    '34': ('flv', '360p'),
    '35': ('flv', '480p'),

    # MPEG4
    '18': ('mp4', '360p'),
    '22': ('mp4', '720p'),
    '37': ('mp4', '1080p'),
    '38': ('mp4', '4K'),
    
    '59': ('mp4', '480p'),
    '78': ('mp4', '480p'),
    
    # WebM
    '43': ('webm', '360p'),
    '44': ('webm', '480p'),
    '45': ('webm', '720p'),
    '46': ('webm', '1080p')
}


def _extract_json_data(html, json_start_string):
    try:
        start = html.find(json_start_string) + len(json_start_string)
        html = html[start:]
        brackets = 0
        offset = 1
        for char in html:
            if char == '{':
                brackets += 1
            elif char == '}':
                brackets -= 1
                if brackets == 0:
                    break
            offset += 1
        else:
            return None
        return json.loads(html[:offset])
    except:
        return None


def get_embed_url(url):
    return url


def resolve(url):
    # video with cipher signature for testing
    # url = 'https://www.youtube.com/watch?v=UxxajLWwzqY'
    
    html = Net().http_GET(url).content
    json_obj = _extract_json_data(html, 'ytplayer.config = ')
    args = json_obj.get('args', {})
    fmt = args.get('url_encoded_fmt_stream_map', '')
    fmts = args.get('adaptive_fmts', '')
    url_encoded_map = ','.join([x for x in (fmt, fmts) if x]).split(',')
    items = [urllib2.parse_keqv_list(s.split('&')) for s in url_encoded_map]
    videos = []
    for item in items:
        if item['itag'] in VIDEO_ENCODING:
            url = urllib.unquote(item['url'])
            if 'signature=' not in url:
                js_url = 'http:' + json_obj['assets']['js']
                js_code = Net().http_GET(js_url, autoDetectEnc=False).content
                decipher_func_name = re.search(r'\.sig\|\|([a-zA-Z0-9$]+)\(', js_code).group(1)
                decipher = JSInterpreter(js_code).extract_function(decipher_func_name)
                sig = decipher([item['s']])
                url = '%s&signature=%s' % (url, sig)
            enc = VIDEO_ENCODING[item['itag']]
            videos.append([url, '%s %s' % (enc[1], enc[0].upper())])
    return [videos, None]
