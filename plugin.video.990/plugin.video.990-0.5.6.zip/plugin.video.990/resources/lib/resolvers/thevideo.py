import re, json
from ..net import Net


def resolve(url):
    url = url.replace('/embed-', '/')
    
    media_id = re.findall(r'//.+?/([\w]+)', url)[0]
    url = 'http://thevideo.me/embed-%s.html' % media_id
    
    html = Net().http_GET(url).content
    html = html.replace('\n', '')
    
    video_sources = re.findall(r'sources *: *(\[.+?\])', html)[-1]
    video_sources = re.findall(r'label *: *[\'|\"](.+?)[\'|\"], file *: *[\'|\"](.+?)[\'|\"]', video_sources)
    
    videos = []
    subtitles = []
    
    for video in video_sources:
        videos.append([video[1], video[0]])
    
    try:
        tracks = re.findall(r'tracks *: *(\[.+?\])', html)[-1]
        tracks = re.sub(r'([\{\s,])(\w+)(:)', r'\1"\2"\3', tracks)
        tracks = json.loads(tracks)
        
        for track in tracks:
            if 'captions' in track['kind']:
                subtitle = (track['file'], track['label'])
                subtitles.append(subtitle)
    except:
        pass
    
    return [videos, subtitles]