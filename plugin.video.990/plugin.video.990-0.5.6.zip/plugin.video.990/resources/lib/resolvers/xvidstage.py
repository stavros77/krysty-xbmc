import re
from ..net import Net
from .. import jsunpack


def resolve(url):
    media_id = re.search(r'https?://(?:www.)?xvidstage.com/([0-9A-Za-z]+)', url).group(1)
    url = 'http://www.xvidstage.com/embed-%s.html' % (media_id)
    html = Net().http_GET(url).content

    match = re.findall(r'(eval.*?\)\)\))', html)
    
    if match:
        jsUnpacked = jsunpack.unpack(match[-1])
        r = re.search(r"\\'file\\',\\'(.+?)\\'", jsUnpacked)
        if r:
            return r.group(1)