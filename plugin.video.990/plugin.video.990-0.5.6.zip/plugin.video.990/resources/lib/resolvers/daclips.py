import re
from ..net import Net


def resolve(url):
    response = Net().http_GET(url, {'Referer': url})
    html = response.content
    
    form_values = {}
    for s in re.finditer(r'<input type="hidden" name="(.+?)" value="(.+?)">', html):
        form_values[s.group(1)] = s.group(2)
    
    html = Net().http_POST(response.get_url(), form_values).content
    
    url = re.search('file\s*:\s*"(.+?)"', html).group(1)
    
    return url