import re
import xbmc, xbmcgui
import urlparse
import traceback


KNOWN_HOSTS = [{
    'file': 'superweb',
    'netloc': ['superweb.ro', 'superweb.rol.ro', 'fastupload.ro'],
    'host': 'SuperWeb',
    'captcha': False
}, {
    'file': 'youtube',
    'netloc': ['youtube.com'],
    'host': 'YouTube',
    'captcha': False
}, {
    'file': 'gorillavid',
    'netloc': ['gorillavid.com', 'gorillavid.in'],
    'host': 'GorillaVid',
    'captcha': False
}, {
    'file': 'daclips',
    'netloc': ['daclips.com', 'daclips.in'],
    'host': 'daCLiPS',
    'captcha': False
}, {
    'file': 'vidbull',
    'netloc': ['vidbull.com'],
    'host': 'VidBull',
    'captcha': False
}, {
    'file': 'vodlocker',
    'netloc': ['vodlocker.com'],
    'host': 'VodLocker',
    'captcha': False
}, {
    'file': 'xvidstage',
    'netloc': ['xvidstage.com'],
    'host': 'XVIDStage',
    'captcha': False
}, {
    'file': 'vidzi',
    'netloc': ['vidzi.tv'],
    'host': 'Vidzi',
    'captcha': False
}, {
    'file': 'movpod',
    'netloc': ['movpod.in', 'movpod.net'],
    'host': 'MovPod',
    'captcha': False
}, {
    'file': 'openload',
    'netloc': ['openload.co', 'openload.io'],
    'host': 'openload',
    'captcha': True
}, {
    'file': 'thevideo',
    'netloc': ['thevideo.me'],
    'host': 'TheVideo',
    'captcha': False
}]


def get_netloc(url):
    if not re.match(r'^(?:http)s?://', url):
        url = 'http://' + url
    n = urlparse.urlparse(url).netloc
    n = n.replace('www.', '').replace('embed.', '')
    n = n.strip().lower()
    return n


def known_host(netloc):
    for r in KNOWN_HOSTS:
        if netloc in r['netloc']:
            return True
    return False


def resolve(url):
    n = get_netloc(url)

    resolver = None

    for r in KNOWN_HOSTS:
        if n in r['netloc']:
            resolver = r
            break

    if not resolver:
        return None

    try:
        r = __import__(resolver['file'], globals(), locals(), [], -1)
        u = r.resolve(url)
        
        if isinstance(u, list):
            video_url = None
            subtitle_url = None
            
            if isinstance(u[0], list):
                labels = ['%s %s' % (resolver['host'], i[1]) for i in u[0]]
                dialog = xbmcgui.Dialog()
                index = dialog.select('Choose your stream', labels)
                if index > -1:
                    video_url = u[0][index][0]
            else:
                video_url = u[0]
            
            if u[1]:
                if isinstance(u[1], list):
                    if len(u[1]) > 1:
                        languages = [i[1] for i in u[1]]
                        dialog = xbmcgui.Dialog()
                        index = dialog.select('Choose subtitle language', languages)
                        if index > -1:
                            subtitle_url = u[1][index][0]
                    else:
                        subtitle_url = u[1][0][0]
                else:
                    subtitle_url = u[1]
            
            return [video_url, subtitle_url]
        
        return [u, None]
        
    except Exception as e:
        print traceback.print_exc()
        xbmc.executebuiltin('Notification(%s, %s, %d)' % ('Resolver Error', e, 5000))
        return None
