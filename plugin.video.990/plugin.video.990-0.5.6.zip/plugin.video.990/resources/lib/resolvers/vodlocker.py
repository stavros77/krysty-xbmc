import re
from ..net import Net


def resolve(url):
    media_id = re.search(r'http://(?:(?:www.)?vodlocker.com)/(?:embed-)?([0-9a-zA-Z]+)(?:-\d+x\d+.html)?', url).group(1)
    url = 'http://vodlocker.com/embed-%s-640x400.html' % (media_id)
    
    html = Net().http_GET(url).content
    
    url = re.search('file\s*:\s*"(.+?)"', html).group(1)
    
    return url