import re, urllib2
from ..net import Net


def resolve(url):
    url = url.replace('/embed-', '/')
    url = url.replace('/vid/', '/')
    
    id = re.findall(r'//.+?/([\w]+)', url)[0]
    url = 'http://movpod.in/embed-%s.html' % id
    
    html = Net().http_GET(url).content
    url = re.findall(r'file *: *"(http.+?)"', html)[-1]
    
    request = urllib2.Request(url)
    response = urllib2.urlopen(request, timeout=10)
    response.close()
    
    type = str(response.info()['Content-Type'])
    
    if 'text/html' in type:
        raise Exception()
    
    return url
