import re
from ..net import Net
from .. import jsunpack


def resolve(url):
    html = Net().http_GET(url).content

    regex = re.compile(r'file\s*:\s*"(.+?)"')
    
    r = regex.search(html)
    
    if r:
        url = r.group(1) + '|Referer=http://vidzi.tv/nplayer/jwplayer.flash.swf'
        return url
    else:
        for match in re.finditer(r'(eval\(function.*?)</script>', html, re.DOTALL):
            js_data = jsunpack.unpack(match.group(1))
            for u in regex.findall(js_data):
                if re.search(r'(?:\.mp4|\.flv)', u):
                   return u