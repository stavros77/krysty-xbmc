import re
from ..net import Net


def get_embed_url(url):
    return url


def resolve(url):
    html = Net().http_GET(url, {'Referer': url}).content
    match = re.search(r'<source src="(.+?)"', html)
    mobile = True if match else False
    if not match:
        match = re.search(r"'file'\s*:\s*'(.+?)',", html)
    
    video_url = None
    subtitles = []
    
    if match:
        video_url = match.group(1) + '|referer=' + url
    
    if mobile:
        subtitles = re.findall(r'<track src="(.+?)".*label="(.+?)"', html)
    else:
        html = ''.join(line.strip() for line in html.split('\n'))
        match = re.search(r"'tracks':\s?\[\{\s?'file':", html)
        
        if match:
            html = html[match.start():]
            subtitles = re.findall(r'\'file\':\s?"(.+?)",\s?\'label\':\s?"(.+?)"', html)
    
    return [video_url, subtitles]
