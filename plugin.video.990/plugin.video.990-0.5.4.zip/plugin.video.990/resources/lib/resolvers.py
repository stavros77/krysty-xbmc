from .net import Net
import jsunpack
import re
import xbmcgui
import urllib, urllib2
import traceback
try:
	from urlparse import urlparse, parse_qs
except ImportError:
	from urllib.parse import urlparse, parse_qs
try:
	import json
except ImportError:
	import simplejson as json


KNOWN_HOSTS = {
    'superweb.rol.ro': ('SuperWeb', 'resolve_superweb'),
    'fastupload.ro': ('SuperWeb', 'resolve_superweb'),
    'superweb.ro': ('SuperWeb', 'resolve_superweb'),

    'youtube.com': ('YouTube', 'resolve_youtube'),

    'gorillavid.in': ('GorillaVid', 'resolve_group1'),
    'gorillavid.com': ('GorillaVid', 'resolve_group1'),

    'daclips.in': ('daCLiPS', 'resolve_group1'),
    'daclips.com': ('daCLiPS', 'resolve_group1'),

    'vidbull.com': ('VidBull', 'resolve_vidbull'),

    'vodlocker.com': ('VodLocker', 'resolve_vodlocker'),

    'vidzi.tv':	('Vidzi', 'resolve_vidzi'),

    'xvidstage.com': ('XVIDStage', 'resolve_xvidstage')
}


def select_subtitle(subtitles_list=[]):
	if not subtitles_list:
		return None
	
	if len(subtitles_list) > 1:
		languages = [item[1] for item in subtitles_list]
		dialog = xbmcgui.Dialog()
		index = dialog.select('Choose subtitle language', languages)
		if index > -1:
			return subtitles_list[index][0]
		else:
			return None
	
	return subtitles_list[0][0]


def resolve(url):
    src = Resolver(url).resolve()

    if not src:
        return None

    index = 0
    if len(src.videos) > 1:
        labels = ['%s %s' % (KNOWN_HOSTS[src.host][0], item[1]) for item in src.videos]
        dialog = xbmcgui.Dialog()
        index = dialog.select('Choose your stream', labels)
        if index == -1:
            return None

    video_url = src.videos[index][0]
    subtitle_url = select_subtitle(src.subtitles)

    return [video_url, subtitle_url]


def _extract_json_data(html, json_start_string):
    try:
        start = html.find(json_start_string) + len(json_start_string)
        html = html[start:]
        brackets = 0
        offset = 1
        for char in html:
            if char == '{':
                brackets += 1
            elif char == '}':
                brackets -= 1
                if brackets == 0:
                    break
            offset += 1
        else:
            return None
        return json.loads(html[:offset])
    except:
        return None

class Hoster:
    def __init__(self, name, domain, plugin_file):
        self.name = name
        self.domain = domain
        self.plugin_file = plugin_file


class Resolver:
    def __init__(self, url):
        self.videos = []
        self.subtitles = []
        self.host = ''
        
        if not re.match(r'^(?:http)s?://', url):
            url = 'http://' + url
        
        self._url = url
        
        try:
            self.host = urlparse(self._url).hostname.replace('www.', '').strip().lower()
        except:
            pass

    def known_resolver(self):
        return self.host in KNOWN_HOSTS

    def resolve(self):
        try:
            if self.known_resolver():
                getattr(self, KNOWN_HOSTS[self.host][1])()
                
                if self.videos:
                    return self
        except:
            traceback.print_exc()
            pass
        
        return False

    def _set_video_url(self, url):
        self.videos.append((url, None))

    def resolve_superweb(self):
        html = Net().http_GET(self._url, {'Referer': self._url}).content
        match = re.search(r'<source src="(.+?)"', html)
        mobile = True if match else False
        if not match:
            match = re.search(r"'file'\s*:\s*'(.+?)',", html)
        
        link = ''
        
        if match:
            link = match.group(1)        
        
        if link:
            link = link + '|referer=' + self._url
            self._set_video_url(link)
        
        if mobile:
            self.subtitles = re.findall(r'<track src="(.+?)".*label="(.+?)"', html)
        else:
            html = ''.join(line.strip() for line in html.split('\n'))
            match = re.search(r"'tracks':\s?\[\{\s?'file':", html)
            
            if match:
                html = html[match.start():]
                self.subtitles = re.findall(r'\'file\':\s?"(.+?)",\s?\'label\':\s?"(.+?)"', html)
        
    def resolve_youtube(self):
        # video with cipher signature for testing
        # self._url = 'https://www.youtube.com/watch?v=UxxajLWwzqY'
        video_encoding = {
            # Flash
            '34': ('flv', '360p'),
            '35': ('flv', '480p'),

            # MPEG4
            '18': ('mp4', '360p'),
            '22': ('mp4', '720p'),
            '37': ('mp4', '1080p'),
            '38': ('mp4', '4K'),
            
            '59': ('mp4', '480p'),
            '78': ('mp4', '480p'),
            
            # WebM
            '43': ('webm', '360p'),
            '44': ('webm', '480p'),
            '45': ('webm', '720p'),
            '46': ('webm', '1080p')
        }
        html = Net().http_GET(self._url).content
        json_obj = _extract_json_data(html, 'ytplayer.config = ')
        args = json_obj.get('args', {})
        fmt = args.get('url_encoded_fmt_stream_map', '')
        fmts = args.get('adaptive_fmts', '')
        url_encoded_map = ','.join([x for x in (fmt, fmts) if x]).split(',')
        items = [urllib2.parse_keqv_list(s.split('&')) for s in url_encoded_map]
        for video in items:
            if video['itag'] in video_encoding:
                url = urllib.unquote(video['url'])
                if 'signature=' not in url:
                    js_url = 'http:' + json_obj['assets']['js']
                    js_code = Net().http_GET(js_url, autoDetectEnc=False).content
                    decipher_func_name = re.search(r'\.sig\|\|([a-zA-Z0-9$]+)\(', js_code).group(1)
                    from .jsinterp import JSInterpreter
                    decipher = JSInterpreter(js_code).extract_function(decipher_func_name)
                    sig = decipher([video['s']])
                    url = '%s&signature=%s' % (url, sig)
                enc = video_encoding[video['itag']]
                self.videos.append((url, '%s %s' % (enc[1], enc[0].upper())))

    # gorillavid, daclips
    def resolve_group1(self):
        response = Net().http_GET(self._url, {'Referer': self._url})
        html = response.content
        
        form_values = {}
        for s in re.finditer(r'<input type="hidden" name="(.+?)" value="(.+?)">', html):
            form_values[s.group(1)] = s.group(2)
        
        html = Net().http_POST(response.get_url(), form_values).content
        
        url = re.search('file\s*:\s*"(.+?)"', html).group(1)
        
        self._set_video_url(url)

    def resolve_vidbull(self):
        net = Net()
        net.set_user_agent(Net.ANDROID_USER_AGENT)
        html = net.http_GET(self._url).content
        
        url = re.search('<source src="(.+?)"', html).group(1)
        
        self._set_video_url(url)

    def resolve_vodlocker(self):
        media_id = re.search(r'http://(?:(?:www.)?vodlocker.com)/(?:embed-)?([0-9a-zA-Z]+)(?:-\d+x\d+.html)?', self._url).group(1)
        url = 'http://vodlocker.com/embed-%s-640x400.html' % (media_id)
        
        html = Net().http_GET(url).content
        
        url = re.search('file\s*:\s*"(.+?)"', html).group(1)
        
        self._set_video_url(url)

    def resolve_vidzi(self):
        html = Net().http_GET(self._url).content

        regex = re.compile(r'file\s*:\s*"(.+?)"')
        
        r = regex.search(html)
        
        if r:
            url = r.group(1) + '|Referer=http://vidzi.tv/nplayer/jwplayer.flash.swf'
            self._set_video_url(url)
        else:
            for match in re.finditer(r'(eval\(function.*?)</script>', html, re.DOTALL):
                js_data = jsunpack.unpack(match.group(1))
                for u in regex.findall(js_data):
                    if re.search(r'(?:\.mp4|\.flv)', u):
                        self._set_video_url(u)
     
    def resolve_xvidstage(self):
        media_id = re.search(r'https?://(?:www.)?xvidstage.com/([0-9A-Za-z]+)', self._url).group(1)
        url = 'http://www.xvidstage.com/embed-%s.html' % (media_id)
        html = Net().http_GET(url).content

        match = re.findall(r'(eval.*?\)\)\))', html)
        
        if match:
            jsUnpacked = jsunpack.unpack(match[-1])
            r = re.search(r"\\'file\\',\\'(.+?)\\'", jsUnpacked)
            if r:
                self._set_video_url(r.group(1))
