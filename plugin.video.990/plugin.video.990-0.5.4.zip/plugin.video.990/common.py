import sys, os
import xbmc, xbmcaddon
from resources.lib.bs4 import BeautifulSoup

addon_id = 'plugin.video.990'

URLS = {
    'base':     'http://www.990.ro/',
    'search':   'http://www.990.ro/functions/search3/live_search_using_jquery_ajax/search.php',
    'tvshows':  'http://www.990.ro/seriale.php',
    'movies':   'http://www.990.ro/toate-filmele.php'
}

HEADERS = {
	'User-Agent': 	 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36',
	'Accept': 		 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Cache-Control': 'no-transform'
}

addon = xbmcaddon.Addon(id=addon_id)
addon_version = addon.getAddonInfo('version')
addon_path = xbmc.translatePath(addon.getAddonInfo('path'))
profile_path = xbmc.translatePath(addon.getAddonInfo('profile'))
cache_path = os.path.join(profile_path, 'cache')
addon_fullname = "%s v%s" % (addon_id, addon_version)

xbmc.log('%s: v%s' % (addon_id, addon_version), 2)

for folder in [profile_path, cache_path]:
    if not os.path.exists(folder):
        os.makedirs(folder)


def log(msg='',level=xbmc.LOGNOTICE):
    #xbmc.LOGDEBUG = 0
    #xbmc.LOGERROR = 4
    #xbmc.LOGFATAL = 6
    #xbmc.LOGINFO = 1
    #xbmc.LOGNONE = 7
    #xbmc.LOGNOTICE = 2
    #xbmc.LOGSEVERE = 5
    #xbmc.LOGWARNING = 3
	xbmc.log('%s: %s' % (addon_id, msg), level)

def getSetting(settingId):
	return addon.getSetting(settingId)

def notify(message,duration=3000):
    title = addon_id + ' Notification'
    icon = os.path.join(addon_path, 'resources', 'media', 'inficon.png')
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (title, message, duration, icon))

def initBeautifulSoup(html):
    return BeautifulSoup(html, 'html5lib')
