import urllib, urllib2, socket, httplib
import re, gzip, StringIO
from cookielib import LWPCookieJar


socket.setdefaulttimeout(10)


class Net:
    CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'
    ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'

    def __init__(self, user_agent='', cookie_file=''):
        self._user_agent = self.CHROME_USER_AGENT
        self._cookiejar = LWPCookieJar()
        
        if user_agent:
            self.set_user_agent(user_agent)
        if cookie_file:
            self.set_cookie_file(cookie_file)
        self._update_opener()
        
        #httplib.HTTPConnection._http_vsn = 10
        #httplib.HTTPConnection._http_vsn_str = 'HTTP/1.0'
        
        #httplib.HTTPConnection._http_vsn = 11
        #httplib.HTTPConnection._http_vsn_str = 'HTTP/1.1'

    def http_GET(self, url, headers={}, compression=True, autoDetectEnc=True):
        return self._get_response(url, headers=headers, compression=compression, autoDetectEnc=autoDetectEnc)

    def http_POST(self, url, form_data, headers={}, compression=True, autoDetectEnc=True):
        return self._get_response(url, form_data, headers, compression, autoDetectEnc)

    def _get_response(self, url, data={}, headers={}, compression=True, autoDetectEnc=True):
        if data:
            data = urllib.urlencode(data)
            req = urllib2.Request(url, data)
        else:
            req = urllib2.Request(url)

        req.add_header('User-Agent', self._user_agent)

        for k, v in headers.items():
            req.add_header(k, v)

        if compression:
            req.add_header('Accept-Encoding', 'gzip')

        return HttpResponse(urllib2.urlopen(req), autoDetectEnc)

    def set_user_agent(self, user_agent):
        self._user_agent = user_agent

    def get_user_agent(self, user_agent):
        return self._user_agent

    def set_cookies(self, cookie_file):
        try:
            self._cookiejar.load(cookie_file, ignore_discard=True)
            self._update_opener()
            return True
        except:
            return False

    def get_cookies(self):
        return self._cookiejar._cookies

    def save_cookies(self, cookie_file):
        self._cookiejar.save(cookie_file, ignore_discard=True)

    def _update_opener(self):
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self._cookiejar),
                                        urllib2.HTTPBasicAuthHandler(),
                                        urllib2.HTTPHandler(),
                                        urllib2.HTTPSHandler()
                                    )
        urllib2.install_opener(opener)


class HttpResponse:
    content = ''

    def __init__(self, response, autoDetectEnc):
        self._response = response

        html = response.read()

        try:
            if response.headers.get('Content-Encoding', '').lower() == 'gzip':
                html = gzip.GzipFile(fileobj=StringIO.StringIO(html)).read()
        except:
            pass
        
        if autoDetectEnc:
            try:
                content_type = response.headers.get('Content-Type')
                if 'charset=' in content_type:
                    encoding = content_type.split('charset=')[-1]
            except:
                pass

            m = re.search(r'<meta\s+http-equiv="Content-Type"\s+content="(?:.+?);\s+charset=(.+?)"', html, re.IGNORECASE)
            if m:
                encoding = m.group(1)

            try:
                html = unicode(html, encoding)
            except:
                pass

        self.content = html

    def get_headers(self):
        return self._response.info().headers

    def get_header(self, name):
        return self._response.info().getheader(name)

    def get_url(self):
        return self._response.geturl()
