import re, xbmc

_code_start = u"\uff9f\u03c9\uff9f\uff89=/\uff40\uff4d\u00b4\uff09\uff89~\u253b\u2501\u253b/['_'];o=(\uff9f\uff70\uff9f)=_=3;c=(\uff9f\u0398\uff9f)=(\uff9f\uff70\uff9f)-(\uff9f\uff70\uff9f);(\uff9f\u0414\uff9f)=(\uff9f\u0398\uff9f)=(o^_^o)/(o^_^o);(\uff9f\u0414\uff9f)={\uff9f\u0398\uff9f:'_',\uff9f\u03c9\uff9f\uff89:((\uff9f\u03c9\uff9f\uff89==3)+'_')[\uff9f\u0398\uff9f],\uff9f\uff70\uff9f\uff89:(\uff9f\u03c9\uff9f\uff89+'_')[o^_^o-(\uff9f\u0398\uff9f)],\uff9f\u0414\uff9f\uff89:((\uff9f\uff70\uff9f==3)+'_')[\uff9f\uff70\uff9f]};(\uff9f\u0414\uff9f)[\uff9f\u0398\uff9f]=((\uff9f\u03c9\uff9f\uff89==3)+'_')[c^_^o];(\uff9f\u0414\uff9f)['c']=((\uff9f\u0414\uff9f)+'_')[(\uff9f\uff70\uff9f)+(\uff9f\uff70\uff9f)-(\uff9f\u0398\uff9f)];(\uff9f\u0414\uff9f)['o']=((\uff9f\u0414\uff9f)+'_')[\uff9f\u0398\uff9f];(\uff9f\u006f\uff9f)=(\uff9f\u0414\uff9f)['c']+(\uff9f\u0414\uff9f)['o']+(\uff9f\u03c9\uff9f\uff89+'_')[\uff9f\u0398\uff9f]+((\uff9f\u03c9\uff9f\uff89==3)+'_')[\uff9f\uff70\uff9f]+((\uff9f\u0414\uff9f)+'_')[(\uff9f\uff70\uff9f)+(\uff9f\uff70\uff9f)]+((\uff9f\uff70\uff9f==3)+'_')[\uff9f\u0398\uff9f]+((\uff9f\uff70\uff9f==3)+'_')[(\uff9f\uff70\uff9f)-(\uff9f\u0398\uff9f)]+(\uff9f\u0414\uff9f)['c']+((\uff9f\u0414\uff9f)+'_')[(\uff9f\uff70\uff9f)+(\uff9f\uff70\uff9f)]+(\uff9f\u0414\uff9f)['o']+((\uff9f\uff70\uff9f==3)+'_')[\uff9f\u0398\uff9f];(\uff9f\u0414\uff9f)['_']=(o^_^o)[\uff9f\u006f\uff9f][\uff9f\u006f\uff9f];(\uff9f\u03b5\uff9f)=((\uff9f\uff70\uff9f==3)+'_')[\uff9f\u0398\uff9f]+(\uff9f\u0414\uff9f).\uff9f\u0414\uff9f\uff89+((\uff9f\u0414\uff9f)+'_')[(\uff9f\uff70\uff9f)+(\uff9f\uff70\uff9f)]+((\uff9f\uff70\uff9f==3)+'_')[o^_^o-\uff9f\u0398\uff9f]+((\uff9f\uff70\uff9f==3)+'_')[\uff9f\u0398\uff9f]+(\uff9f\u03c9\uff9f\uff89+'_')[\uff9f\u0398\uff9f];(\uff9f\uff70\uff9f)+=(\uff9f\u0398\uff9f);(\uff9f\u0414\uff9f)[\uff9f\u03b5\uff9f]='\\\\';(\uff9f\u0414\uff9f).\uff9f\u0398\uff9f\uff89=(\uff9f\u0414\uff9f+\uff9f\uff70\uff9f)[o^_^o-(\uff9f\u0398\uff9f)];(o\uff9f\uff70\uff9fo)=(\uff9f\u03c9\uff9f\uff89+'_')[c^_^o];(\uff9f\u0414\uff9f)[\uff9f\u006f\uff9f]='\\\"';(\uff9f\u0414\uff9f)['_']((\uff9f\u0414\uff9f)['_'](\uff9f\u03b5\uff9f+(\uff9f\u0414\uff9f)[\uff9f\u006f\uff9f]+"

_code_end = u"(\uff9f\u0414\uff9f)[\uff9f\u006f\uff9f])(\uff9f\u0398\uff9f))('_');"

_bytes = [
    (9, u'((\uff9f\uff70\uff9f)+(\uff9f\uff70\uff9f)+(\uff9f\u0398\uff9f))'),
    (6, [u'((o^_^o)+(o^_^o)+(c^_^o))', u'((o^_^o)+(o^_^o))']),
    (2, [u'((o^_^o)-(\uff9f\u0398\uff9f))', u'(!+[]+!+[])']),
    (7, u'((\uff9f\uff70\uff9f)+(o^_^o))'),
    (5, u'((\uff9f\uff70\uff9f)+(\uff9f\u0398\uff9f))'),
    (8, u'((\uff9f\uff70\uff9f)+(\uff9f\uff70\uff9f))'),
    (10, u'(\uff9f\u0414\uff9f).\uff9f\u03c9\uff9f\uff89'),
    (11, u'(\uff9f\u0414\uff9f).\uff9f\u0398\uff9f\uff89'),
    (12, u'(\uff9f\u0414\uff9f)[\'c\']'),
    (13, u'(\uff9f\u0414\uff9f).\uff9f\uff70\uff9f\uff89'),
    (14, u'(\uff9f\u0414\uff9f).\uff9f\u0414\uff9f\uff89'),
    (15, u'(\uff9f\u0414\uff9f)[\uff9f\u0398\uff9f]'),
    (3, u'(o^_^o)'),
    (0, [u'((c^_^o)+(c^_^o))', '((c^_^o)-(c^_^o))', u'(c^_^o)']),
    (4, [u'(\uff9f\uff70\uff9f)', u'(-~-~(!+[]+!+[]))']),
    (1, [u'(\uff9f\u0398\uff9f)', u'(+!+[])'])
]


def decode(js):
    js = re.sub(r'\/\*.+?\*\/', '', js)
    js = re.sub(r'[\x03-\x20]', '', js)
    
    if _code_start not in js and _code_end not in js:
        raise Exception('Given code is not encoded as aaEncode.')
    
    index_start = len(_code_start)
    index_end = len(js) - len(_code_end)
    
    js = js[index_start:index_end]
    
    for byte, search in _bytes:
        if isinstance(search, list):
            for s in search:
                js = js.replace(s, str(byte))
        else:
            js = js.replace(search, str(byte))
    
    js = re.sub(r'\([-~0-9]+\)', lambda m: str(eval(m.group(0))), js)
    
    decoded = ''
    
    blocks = js.split(u'(\uff9f\u0414\uff9f)[\uff9f\u03b5\uff9f]+')
    
    for block in blocks:
        code_octal = ''.join(block.strip('+').split('+'))
        if code_octal.isdigit():
            code_decimal = int(code_octal, 8)
            decoded += chr(code_decimal)
    
    return decoded
