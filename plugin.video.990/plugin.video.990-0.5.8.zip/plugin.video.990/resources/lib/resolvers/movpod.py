import re, urllib2
from ..net import Net


def get_embed_url(url):
    u = url.replace('/embed-', '/').replace('/vid/', '/')
    ids = re.findall(r'//.+?/([\w]+)', u)
    if ids:
        return 'http://movpod.in/embed-%s.html' % ids[0]
    return url


def resolve(url):
    url = get_embed_url(url)
    
    html = Net().http_GET(url).content
    url = re.findall(r'file *: *"(http.+?)"', html)[-1]
    
    request = urllib2.Request(url)
    response = urllib2.urlopen(request, timeout=10)
    response.close()
    
    type = str(response.info()['Content-Type'])
    
    if 'text/html' in type:
        raise Exception()
    
    return url
