import re
from ..net import Net


def get_embed_url(url):
    return url


def resolve(url):
    net = Net()
    net.set_user_agent(Net.ANDROID_USER_AGENT)
    html = net.http_GET(url).content
    
    url = re.search('<source src="(.+?)"', html).group(1)
    
    return url
