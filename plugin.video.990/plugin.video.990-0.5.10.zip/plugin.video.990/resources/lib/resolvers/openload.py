import re, json, urllib
from ..net import Net
import xbmc
from .. import captcha_lib, utils
from ..aa_decode import AADecoder


_regex = re.compile(r'//.+?/(?:embed|f)/([0-9a-zA-Z-_]+)')
_url_regex = re.compile(r'((?:https?):(?:(?:\/\/)|(?:\\\\))+(?:[\w\d:#@%/;$()~_?\+-=\\\.&](?:#!)?)*)')

def get_embed_url(url):
    ids = _regex.findall(url)
    if ids:
        return 'https://openload.co/embed/%s/' % ids[0]
    return url


def openload_debase(js):
    m = re.search(r'toString\([a-z]\s?([+\-*/])\s?(\d+)\)', js)
    if m:
        op = m.group(1)
        const = m.group(2)
        replace_func = lambda m: utils.str_base(int(m.group(2)), int(eval(op.join([m.group(1), const]))))
        js = re.sub(r'\(([0-9]+),\s?([0-9]+)\)', replace_func, js)
        js = js.replace('"', '').replace('+', '')
    return js


def resolve(url):
    url = get_embed_url(url)
    media_id = _regex.search(url).group(1)

    net = Net()

    html = net.http_GET(url).content
    if any(x in html for x in ['We are sorry', 'File not found']):
        raise Exception('The file was removed')

    video_url = ''
    subtitles = []

    try:
        subtitles = re.findall(r'<track kind="captions" src="(.+?)" .+? label="(.+?)" .+?>', html)
    except:
        pass

    try:
        i = html.find('id="olvideo"')
        if i == -1:
            raise Exception()

        m = re.findall(r'text\/javascript">(.+?)<\/script>', html[i:], re.DOTALL)

        v_urls = []
        var_name = ''
        
        aa = AADecoder()
        for js_c in m:
            aa.set_encoded(js_c)
            if aa.is_aa_encoded():
                js_dec = openload_debase(aa.decode())
                m = re.search(r'src:\s?.+?\[(.+?)\]', js_dec)
                if m:
                    var_name = m.group(1).strip()
                m = _url_regex.search(js_dec)
                if m:
                    v_urls.append(m.group(1).strip())
        
        if var_name:
            m = re.search(r'%s\s?=\s?([\d\-+*/ ]+);' % var_name, html)
            if m:
                i = eval(m.group(1))
                video_url = '%s|User-Agent=%s&Referer=%s' % (v_urls[i-1], urllib.quote_plus(net.CHROME_USER_AGENT), urllib.quote_plus(url))
        
        return [video_url, subtitles]
    except:
        pass

    ticket_url = 'https://api.openload.io/1/file/dlticket?file=%s' % media_id

    result = net.http_GET(ticket_url).content   
    json_result = json.loads(result)

    if json_result['status'] != 200:
        raise Exception(json_result['msg'])

    video_url = 'https://api.openload.io/1/file/dl?file=%s&ticket=%s' % (media_id, json_result['result']['ticket'])

    captcha_img_url = json_result['result'].get('captcha_url', None)

    if captcha_img_url:
        captcha_response = captcha_lib.get_response(captcha_img_url)
        if captcha_response:
            video_url += '&captcha_response=%s' % urllib.quote(captcha_response)

    xbmc.sleep(json_result['result']['wait_time'] * 1000)

    result = net.http_GET(video_url).content
    json_result = json.loads(result)

    if json_result['status'] != 200:
        raise Exception(json_result['msg'])

    video_url = json_result['result']['url'] + '?mime=true'

    return [video_url, subtitles]
