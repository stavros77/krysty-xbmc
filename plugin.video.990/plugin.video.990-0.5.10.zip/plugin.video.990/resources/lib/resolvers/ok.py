import re, urlparse, urllib, json
from ..net import Net
import xbmc

def get_embed_url(url):
    return url


def resolve(url):
    id = re.search('\d+', url).group(0)
    u = urlparse.urlparse(url)
    xbmc.log(url, 2)
    hostUrl = '://'.join([u.scheme, u.netloc])
    jsonUrl = 'http://ok.ru/dk?cmd=videoPlayerMetadata&mid=' + id
    
    response = Net().http_GET(jsonUrl)
    
    jsonSource = json.loads(response.content)
    
    quality = {
        'mobile':   '144p',
        'lowest':   '240p',
        'low':      '360p',
        'sd':       '480p',
        'hd':       '720p',
        'full':     '1080p'
    }
    
    params = {
        'User-Agent':   Net.CHROME_USER_AGENT,
        'Referer':      url,
        'Origin':       hostUrl
    }
    params = urllib.urlencode(params)
    
    videos = []
    subtitles = []
    
    for source in jsonSource['videos']:
        q = source['name'].strip()
        q = quality.get(q, None)
        if not q:
            continue
        
        link = '|'.join([source['url'], params])
        
        videos.append([link, q])
    
    return [videos, subtitles]
