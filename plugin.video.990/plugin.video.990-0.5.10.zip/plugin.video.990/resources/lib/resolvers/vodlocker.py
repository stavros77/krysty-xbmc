import re
from ..net import Net


def get_embed_url(url):
    ids = re.search(r'http://(?:(?:www.)?vodlocker.com)/(?:embed-)?([0-9a-zA-Z]+)(?:-\d+x\d+.html)?', url)
    if ids:
        return 'http://vodlocker.com/embed-%s-640x400.html' % ids.group(1)
    return url


def resolve(url):
    url = get_embed_url(url)
    
    html = Net().http_GET(url).content
    
    url = re.search('file\s*:\s*"(.+?)"', html).group(1)
    
    return url
