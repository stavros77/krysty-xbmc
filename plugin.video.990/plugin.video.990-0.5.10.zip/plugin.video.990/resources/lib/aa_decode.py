# -*- coding: utf-8 -*-

import re

_code_start = ''.join([
    u"ﾟωﾟﾉ=/｀ｍ´）ﾉ~┻━┻/['_'];",
    u"o=(ﾟｰﾟ)=_=3;",
    u"c=(ﾟΘﾟ)=(ﾟｰﾟ)-(ﾟｰﾟ);",
    u"(ﾟДﾟ)=(ﾟΘﾟ)=(o^_^o)/(o^_^o);",
    u"(ﾟДﾟ)={ﾟΘﾟ:'_',ﾟωﾟﾉ:((ﾟωﾟﾉ==3)+'_')[ﾟΘﾟ],ﾟｰﾟﾉ:(ﾟωﾟﾉ+'_')[o^_^o-(ﾟΘﾟ)],ﾟДﾟﾉ:((ﾟｰﾟ==3)+'_')[ﾟｰﾟ]};",
    u"(ﾟДﾟ)[ﾟΘﾟ]=((ﾟωﾟﾉ==3)+'_')[c^_^o];",
    u"(ﾟДﾟ)['c']=((ﾟДﾟ)+'_')[(ﾟｰﾟ)+(ﾟｰﾟ)-(ﾟΘﾟ)];",
    u"(ﾟДﾟ)['o']=((ﾟДﾟ)+'_')[ﾟΘﾟ];",
    u"(ﾟoﾟ)=(ﾟДﾟ)['c']+(ﾟДﾟ)['o']+(ﾟωﾟﾉ+'_')[ﾟΘﾟ]+((ﾟωﾟﾉ==3)+'_')[ﾟｰﾟ]+((ﾟДﾟ)+'_')[(ﾟｰﾟ)+(ﾟｰﾟ)]+((ﾟｰﾟ==3)+'_')[ﾟΘﾟ]+((ﾟｰﾟ==3)+'_')[(ﾟｰﾟ)-(ﾟΘﾟ)]+(ﾟДﾟ)['c']+((ﾟДﾟ)+'_')[(ﾟｰﾟ)+(ﾟｰﾟ)]+(ﾟДﾟ)['o']+((ﾟｰﾟ==3)+'_')[ﾟΘﾟ];",
    u"(ﾟДﾟ)['_']=(o^_^o)[ﾟoﾟ][ﾟoﾟ];",
    u"(ﾟεﾟ)=((ﾟｰﾟ==3)+'_')[ﾟΘﾟ]+(ﾟДﾟ).ﾟДﾟﾉ+((ﾟДﾟ)+'_')[(ﾟｰﾟ)+(ﾟｰﾟ)]+((ﾟｰﾟ==3)+'_')[o^_^o-ﾟΘﾟ]+((ﾟｰﾟ==3)+'_')[ﾟΘﾟ]+(ﾟωﾟﾉ+'_')[ﾟΘﾟ];",
    u"(ﾟｰﾟ)+=(ﾟΘﾟ);",
    u"(ﾟДﾟ)[ﾟεﾟ]='\\\\';",
    u"(ﾟДﾟ).ﾟΘﾟﾉ=(ﾟДﾟ+ﾟｰﾟ)[o^_^o-(ﾟΘﾟ)];",
    u"(oﾟｰﾟo)=(ﾟωﾟﾉ+'_')[c^_^o];",
    u"(ﾟДﾟ)[ﾟoﾟ]='\\\"';",
    u"(ﾟДﾟ)['_']((ﾟДﾟ)['_'](ﾟεﾟ+(ﾟДﾟ)[ﾟoﾟ]+"
])

_code_end = u"(ﾟДﾟ)[ﾟoﾟ])(ﾟΘﾟ))('_');"

_bytes = [
    (0, u'(c^_^o)'),
    (1, u'(ﾟΘﾟ)'),
    (3, u'(o^_^o)'),
    (4, u'(ﾟｰﾟ)'),
    (10, u'(ﾟДﾟ).ﾟωﾟﾉ'),
    (11, u'(ﾟДﾟ).ﾟΘﾟﾉ'),
    (12, u'(ﾟДﾟ)[\'c\']'),
    (13, u'(ﾟДﾟ).ﾟｰﾟﾉ'),
    (14, u'(ﾟДﾟ).ﾟДﾟﾉ'),
    (15, u'(ﾟДﾟ)[ﾟΘﾟ]')
]

class AADecoder(object):
    def __init__(self):
        self.encoded = ''
        self.decoded = ''
    
    def set_encoded(self, s):
        s = re.sub(r'\/\*.+?\*\/', '', s)
        s = re.sub(r'[\x03-\x20]', '', s)
        self.encoded = s
    
    def is_aa_encoded(self, s=''):
        s = self.encoded if not s else s
        return _code_start in s and _code_end in s
    
    def get_decoded(self):
        return self.decoded
    
    def decode(self):
        if not self.is_aa_encoded():
            raise Exception('Given code is not encoded as aaEncode.')
        
        i = len(_code_start)
        j = len(self.encoded) - len(_code_end)
        
        s = self.encoded[i:j]
        
        for b1, b0 in _bytes:
            s = s.replace(b0, str(b1))
        
        s = re.sub(r'\([-~+0-9]+\)', lambda m: str(eval(m.group(0))), s)
        
        self.decoded = ''
        
        blocks = s.split(u'(ﾟДﾟ)[ﾟεﾟ]+')
        
        for block in blocks:
            code_octal = ''.join(block.strip('+').split('+'))
            if code_octal.isdigit():
                code_decimal = int(code_octal, 8)
                self.decoded += chr(code_decimal)
        
        return self.decoded
