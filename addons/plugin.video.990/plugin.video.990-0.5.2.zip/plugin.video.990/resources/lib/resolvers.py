from .net import Net
import jsunpack
import re
import xbmcgui
import urllib, urllib2
try:
	from urlparse import urlparse, parse_qs
except ImportError:
	from urllib.parse import urlparse, parse_qs
try:
	import json
except ImportError:
	import simplejson as json


KNOWN_HOSTS = {
		'superweb.rol.ro': ('SuperWeb', 'resolve_superweb'),
		'fastupload.ro': ('SuperWeb', 'resolve_superweb'),
		'superweb.ro': ('SuperWeb', 'resolve_superweb'),
		'superweb.rol.ro': ('SuperWeb', 'resolve_superweb'),
		
		'youtube.com': ('YouTube', 'resolve_youtube'),
		
		'gorillavid.in': ('GorillaVid', 'resolve_group1'),
		'gorillavid.com': ('GorillaVid', 'resolve_group1'),
		
		'daclips.in': ('daCLiPS', 'resolve_group1'),
		'daclips.com': ('daCLiPS', 'resolve_group1'),
		
		'vidbull.com': ('VidBull', 'resolve_vidbull'),
		
		'vodlocker.com': ('VodLocker', 'resolve_vodlocker'),
		
		'vidzi.tv':	('Vidzi', 'resolve_vidzi'),
		
		'180upload.com': ('180Upload', 'resolve_180upload'),
		'hugefiles.net': ('HugeFiles', 'resolve_hugefiles'),
		'clicknupload.com': ('ClicknUpload', 'resolve_clicknupload'),
		'tusfiles.net': ('TusFiles', 'resolve_tusfiles'),
		'xfileload.com': ('XfileLoad', 'resolve_xfileload'),
		'mightyupload.com': ('MightyUpload', 'resolve_mightyupload'),
		'donevideo.com': ('DoneVideo', 'resolve_donevideo'),
		'vidplay.net': ('VidPlay', 'resolve_vidplay'),
		'24uploading.com': ('24Uploading', 'resolve_24uploading'),
		'xvidstage.com': ('XVIDStage', 'resolve_xvidstage')
	}

# return type:
# string_subtitle_url; None on Fail
def select_subtitle(subtitles_list=[]):
	if not subtitles_list:
		return None
	
	if len(subtitles_list) > 1:
		languages = [item[1] for item in subtitles_list]
		dialog = xbmcgui.Dialog()
		index = dialog.select('Choose subtitle language', languages)
		if index > -1:
			return subtitles_list[index][0]
		else:
			return None
	
	return subtitles_list[0][0]


# return type:
# list [string_stream_url, string_subtitle_url or None]; None on Fail
# [str, str]
def resolve(url, enableSubtitle=True):
	if not re.match(r'^(?:http)s?://', url):
		url = 'http://' + url
	
	domain = urlparse(url).hostname.replace('www.', '').strip().lower()
	
	if domain in KNOWN_HOSTS:
		src = getattr(Resolvers(), KNOWN_HOSTS[domain][1])(url)
		
		if not src:
			return None
		
		index = 0
		if len(src) > 1:
			labels = ['%s %s' % (KNOWN_HOSTS[domain][0], item[2]) for item in src]
			dialog = xbmcgui.Dialog()
			index = dialog.select('Choose your stream', labels)
			if index == -1:
				return None
		
		video_url = src[index][0]
		
		if not enableSubtitle:
			return [video_url, None]
		
		return [video_url, select_subtitle(src[index][1])]
		
	return None


def _extract_json_data(html, json_start_string):
    try:
        start = html.find(json_start_string) + len(json_start_string)
        html = html[start:]
        brackets = 0
        offset = 1
        for char in html:
            if char == '{':
                brackets += 1
            elif char == '}':
                brackets -= 1
                if brackets == 0:
                    break
            offset += 1
        else:
            return None
        return json.loads(html[:offset])
    except:
        return None


# return type:
# list of tuples (string_stream_url, list_of_subtitles, quality); None on Fail
# [(str, [], None)]
class Resolvers:
    mobile_user_agent = 'Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/BuildID) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36'

    def resolve_superweb(self, url):
        try:
            html = Net().http_GET(url, {'Referer': url}).content
            
            match = re.search(r"'file'\s*:\s*'(.+?)',", html)
            link = match.group(1) + '|referer=' + url
            
            subtitles = []
            
            match = re.search(r"'captions\.file'\s*:\s*'(.+?)',", html)
            if match:
                subtitle = (match.group(1), 'RO')
                subtitles.append(subtitle)
            
            return [(link, subtitles, None)]
        
        except Exception as e:
            print e
            return None
        
    def resolve_youtube(self, url):
        # video with cipher signature for testing
        # url = 'https://www.youtube.com/watch?v=UxxajLWwzqY'
        try:
            video_encoding = {
                # Flash
                '34': ('flv', '360p'),
                '35': ('flv', '480p'),

                # MPEG4
                '18': ('mp4', '360p'),
                '22': ('mp4', '720p'),
                '37': ('mp4', '1080p'),
                '38': ('mp4', '4K'),
                
                '59': ('mp4', '480p'),
                '78': ('mp4', '480p'),
                
                # WebM
                '43': ('webm', '360p'),
                '44': ('webm', '480p'),
                '45': ('webm', '720p'),
                '46': ('webm', '1080p')
            }
            html = Net().http_GET(url).content
            json_obj = _extract_json_data(html, 'ytplayer.config = ')
            args = json_obj.get('args', {})
            fmt = args.get('url_encoded_fmt_stream_map', '')
            fmts = args.get('adaptive_fmts', '')
            url_encoded_map = ','.join([x for x in (fmt, fmts) if x]).split(',')
            items = [urllib2.parse_keqv_list(s.split('&')) for s in url_encoded_map]
            videos = []
            for video in items:
                if video['itag'] in video_encoding:
                    url = urllib.unquote(video['url'])
                    if 'signature=' not in url:
                        js_url = 'http:' + json_obj['assets']['js']
                        js_code = Net().http_GET(js_url, autoDetectEnc=False).content
                        decipher_func_name = re.search(r'\.sig\|\|([a-zA-Z0-9$]+)\(', js_code).group(1)
                        from .jsinterp import JSInterpreter
                        decipher = JSInterpreter(js_code).extract_function(decipher_func_name)
                        sig = decipher([video['s']])
                        url = '%s&signature=%s' % (url, sig)
                    enc = video_encoding[video['itag']]
                    videos.append((url, [], '%s %s' % (enc[1], enc[0].upper())))
            return videos
        
        except Exception as e:
            print e
            return None

    # gorillavid, daclips
    def resolve_group1(self, url):
        try:
            response = Net().http_GET(url, {'Referer': url})
            html = response.content
            
            form_values = {}
            for s in re.finditer(r'<input type="hidden" name="(.+?)" value="(.+?)">', html):
                form_values[s.group(1)] = s.group(2)
            
            html = Net().http_POST(response.get_url(), form_values).content
            
            url = re.search('file\s*:\s*"(.+?)"', html).group(1)
            
            return [(url, None, None)]
        
        except Exception as e:
            print e
            return None

    def resolve_vidbull(self, url):
        try:
            html = Net().http_GET(url, {'User-Agent': self.mobile_user_agent}).content
            
            url = re.search('<source src="(.+?)"', html).group(1)
            
            return [(url, None, None)]
        
        except Exception as e:
            print e
            return None

    def resolve_vodlocker(self, url):
        try:
            media_id = re.search(r'http://(?:(?:www.)?vodlocker.com)/(?:embed-)?([0-9a-zA-Z]+)(?:-\d+x\d+.html)?', url).group(1)
            url = 'http://vodlocker.com/embed-%s-640x400.html' % (media_id)
            
            html = Net().http_GET(url).content
            
            url = re.search('file\s*:\s*"(.+?)"', html).group(1)
            
            return [(url, None, None)]
        
        except Exception as e:
            print e
            return None

    def resolve_vidzi(self, url):
        html = Net().http_GET(url).content

        regex = re.compile(r'file\s*:\s*"(.+?)"')
        
        r = regex.search(html)

        if r:
            url = r.group(1) + '|Referer=http://vidzi.tv/nplayer/jwplayer.flash.swf'
            return [(url, None, None)]
        else:
            for match in re.finditer(r'(eval\(function.*?)</script>', html, re.DOTALL):
                js_data = jsunpack.unpack(match.group(1))
                for u in regex.findall(js_data):
                    if re.search(r'(?:\.mp4|\.flv)', u):
                        return [(u, None, None)]
        return None