import os, re, time, codecs
try:
	import json
except ImportError:
	import simplejson as json
from resources.lib import htmlcleaner

def save_to_cache(type, data, filePath):
    filePath += '.cache'
    try:
        with codecs.open(filePath, 'w', encoding='utf-8') as f:
            if type == 'json':
                f.write(json.dumps(data))
            elif type == 'string':
                f.write(data)
    except:
        pass


def load_from_cache(type, filePath, expire_hours):
    filePath += '.cache'
    data = None
    try:
        if os.path.isfile(filePath):
            if (os.path.getsize(filePath) > 0) and ((time.time() - os.path.getmtime(filePath)) <= expire_hours * 60 * 60):
                with open(filePath, 'r') as f:
                    if type == 'json':
                        data = json.loads(f.read())
                    elif type == 'string':
                        data = f.read()
            else:
                os.remove(filePath)
    except:
        pass
    return data


def clearCache(cache_folder_path):
    flag = True
    try:
        filelist = [file for file in os.listdir(cache_folder_path) if file.endswith('.cache')]
        for file in filelist:
            os.remove(os.path.join(cache_folder_path, file))
    except:
        flag = False
    return flag


def intTryParse(value):
    try:
        return int(value)
    except ValueError:
        return 0


def bytesToHumanReadable(size, precision=2, bsize=1024):
	if size == 1:
		return '1 byte'
	units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
	size = float(size)
	i = 0
	while size > bsize:
		i += 1
		size = size / bsize
	if precision == 0:
		return int(size)
	return '%s %s' % (round(size, precision), units[i])


def bytesTo(size, to='kB', precision=2, bsize=1024):
	a = ['KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
	size = float(size)
	for i in range(a.index(to.upper()) + 1):
		size = size / bsize
	if precision == 0:
		return int(size)
	return round(size, precision)


def unescape(string, strip=False):
	if string == '':
		return string
	unichars = (
		('', u'\u200e'),
		('', u'\u200f'),
		('-', u'\u2013'),
		('-', u'\u2014')
	)
	utfchars = (
		('', '\xe2\x80\x8e'),
		('', '\xe2\x80\x8f'),
		('-', '\xe2\x80\x93'),
		('-', '\xe2\x80\x94')
	)
	if isinstance(string, unicode):
		for code in unichars:
			string = string.replace(code[1], code[0])
	elif isinstance(string, str):
		for code in utfchars:
			string = string.replace(code[1], code[0])
	html_codes = (
		("'", '&#39;'),
		('"', '&quot;'),
		('>', '&gt;'),
		('<', '&lt;'),
		('&', '&amp;'),
		('-', '&ndash;'),
		('-', '&mdash;')
	)
	hex2dec = lambda x: re.sub(r'&#x([^;]+);', lambda m: '&#%d;' % int(m.group(1), 16), x)
	dec2uni = lambda x: re.sub(r'&#([^x;]+);', lambda m: unichr(int(m.group(1))), x)
	string = hex2dec(string)
	string = dec2uni(string).encode('utf-8')
	for code in html_codes:
		string = string.replace(code[1], code[0])
	if strip:
		string = htmlcleaner.clean(string, True)
	return string


def convert_seconds(seconds):
	m, s = divmod(seconds, 60)
	h, mins = divmod(m, 60)
	if m > 60:
		return "%02d:%02d:%02d" % (h, mins, s)
	return "%02d:%02d" % (m, s)


def titlecase(s):
	return re.sub(r"[A-Za-z]+('[A-Za-z]+)?", lambda mo: mo.group(0)[0].upper() + mo.group(0)[1:].lower(), s)


def remove_all_whitespaces(string):
	return ''.join(line.strip() for line in string.split('\n'))
