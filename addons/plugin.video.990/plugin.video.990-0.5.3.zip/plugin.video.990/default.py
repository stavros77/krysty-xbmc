"""
	990.ro XBMC Addon
	Copyright (C) 2012-2015 krysty
	https://github.com/yokrysty/krysty-xbmc

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program. If not, see <http://www.gnu.org/licenses/>.
"""

import sys, os, re, string
import urllib, urllib2
import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import common, utils, scraper, db
from resources.lib.net import Net
from resources.lib.bs4 import BeautifulSoup
from resources.lib.ga import track
import resources.lib.resolvers as resolvers
from resources.lib.metahandler import metahandlers


REMOTE_DEBUG = False
if REMOTE_DEBUG:
	sys.path.append('C:\\Users\\KRYSTY\\Desktop\\eclipse\\plugins\\org.python.pydev_4.3.0.201508182223\\pysrc')
	import pydevd
	pydevd.settrace('localhost', stdoutToServer=True, stderrToServer=True)


CREATE_META_ZIP = False

ICONS = {
	'tvshows':	'tvshowsicon.png',
	'movies':	'moviesicon.png',
	'search':	'searchicon.png',
	'info': 	'inficon.png',
	'settings':	'settingsicon.png'
}

for icon in ICONS:
	ICONS[icon] = os.path.join(common.addon_path, 'resources', 'media', ICONS[icon])

DB = db.DB()

track(common.addon_fullname)

def get_params():
	params = {}
	if len(sys.argv[2]) >= 2:
			query = sys.argv[2].replace('?','')
			if (query[len(query)-1] == '/'):
				query = query[0:len(query)-2]
			pairsparams = query.split('&')
			for i in range(len(pairsparams)):
				splitparams = pairsparams[i].split('=')
				if (len(splitparams) == 2):
					params[splitparams[0]] = urllib.unquote_plus(splitparams[1])
	return params


PARAMS = get_params()

MODE = int(PARAMS.get('mode', 0))
URL = PARAMS.get('url', '')
NAME = PARAMS.get('name', '')
THUMBNAIL = PARAMS.get('thumbnail', '')
VIDEO_TYPE = PARAMS.get('video_type', '')
TVSHOWNAME = PARAMS.get('tvshowname', '')
SEASON = PARAMS.get('season', '')
EPISODE = PARAMS.get('episode', '')
EP_NAME = PARAMS.get('ep_name', '')
YEAR = PARAMS.get('year', '')
IMDB_ID = PARAMS.get('imdb_id', '')
TVSHOWTHUMBNAIL = PARAMS.get('tvshowthumb', '')

if MODE == 14:
    PARAMS['tvshowthumb'] = THUMBNAIL

common.log('------------------PARAMS------------------')
common.log('--- Mode: ' + str(MODE))
common.log('--- Url: ' + URL)
common.log('--- Name: ' + NAME)
common.log('--- Thumbnail: ' + THUMBNAIL)
common.log('--- Video Type: ' + VIDEO_TYPE)
common.log('--- TV Show Name: ' + TVSHOWNAME)
common.log('--- Year: ' + YEAR)
common.log('--- Season: ' + SEASON)
common.log('--- Episode: ' + EPISODE)
common.log('--- Episode Name: ' + EP_NAME)
common.log('--- IMDB ID: ' + IMDB_ID)
common.log('--- TV Show Thumbnail: ' + TVSHOWTHUMBNAIL)
common.log('------------------------------------------')

ENABLE_META = common.addon.getSetting('useMeta') == 'true'

if ENABLE_META:
    MetaGet = metahandlers.MetaData()
    NO_META_COVERS_FOUND = []

def main():
	addDir('TV Shows','',10,ICONS['tvshows'])
	addDir('Movies',common.URLS['movies'],20,ICONS['movies'])
	addDir('Search',common.URLS['base'],30,ICONS['search'])
	addDir('Settings',common.URLS['base'],95,ICONS['settings'])
	addDir('Clear Cache',common.URLS['base'],96)
	if CREATE_META_ZIP:
		addDir('Create Meta Pack',common.URLS['base'],999)
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def tvShowsIndex():
	AZ = (ltr for ltr in string.ascii_uppercase)
	
	if common.addon.getSetting('enableAllCat') == 'true':
		addDir('All','',11,ICONS['tvshows'])
	
	addDir('Recently Added','',40,ICONS['tvshows'])
	addDir('Search','',31,ICONS['tvshows'])
	addDir('[1-9]','',12,ICONS['tvshows'])
	for character in AZ:
		addDir(character,'',12,ICONS['tvshows'])
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def getTVShows(filter=None):
    tvshows = scraper.getTVShows(filter)
    
    total = len(tvshows)
    
    if total <= 0:
        xbmcgui.Dialog().ok('', 'Error: something went wrong.')
        sys.exit()
    
    for tvshow in tvshows:
        addItem(tvshow['name'], tvshow['url'], 100, year=tvshow['year'], totalItems=total)


def getSeasons(url):
    global TVSHOWNAME

    seasons = scraper.getSeasons(url)

    if seasons <= 0:
        xbmcgui.Dialog().ok('', 'Error: something went wrong.')
        sys.exit()

    if ENABLE_META:
        seasons_meta = MetaGet.get_seasons(TVSHOWNAME, IMDB_ID, seasons)

    for season in range(1, seasons + 1):
        season_str = str(season).zfill(2)
        name = 'Season %s' % season_str
        link = url + '?season=' + season_str
        
        if ENABLE_META:
            addItem(name, link, 101, totalItems=seasons, meta=seasons_meta[season - 1])
        else:
            addItem(name, link, 101, totalItems=seasons)


def getEpisodes(url):
    global TVSHOWNAME
    
    url, season = url.split('?season=')

    episodes = scraper.getEpisodes(url, season)
    
    total = len(episodes)
    
    if total <= 0:
        xbmcgui.Dialog().ok('', 'Error: something went wrong.')
        sys.exit()
    
    for episode in episodes:
        addItem(TVSHOWNAME, episode['url'], 103, season=episode['season'], ep_num=episode['number'], ep_name=episode['name'], folder=False, totalItems=total)


def moviesIndex(url,order=None):
    if order:
        categories = scraper.getVideoCategories(order)
        
        total = len(categories)
        
        for category in categories:
            addDir(category['name'], category['url'], 23, ICONS['movies'], totalItems=total)

    else:
        addDir('Search',url,32,ICONS['movies'])
        addDir('Recently Added',url,41,ICONS['movies'])
        addDir('By Year',url,21,ICONS['movies'])
        addDir('By Genre',url,22,ICONS['movies'])

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def getMovies(url, all=False):
    m = re.search(r'pagina=(\d+)', url)
    current_page = int(m.group(1)) if m else 1
    total_pages = scraper.getTotalPages(url)

    total_movies = 0

    while current_page <= total_pages:
        movies = scraper.getMovies(url)
        
        count = len(movies)
        
        if count <= 0:
            xbmcgui.Dialog().ok('', 'Error: something went wrong.')
            sys.exit()
        
        if all:
            if current_page == 1:
                total_movies = count * total_pages
            
            elif current_page == total_pages:
                total_movies = total_movies - (total_movies / total_pages) + count
        else:
            total_movies = count
        
        for movie in movies:
            addItem(movie['name'], movie['url'], 200, year=movie['year'], folder=False, totalItems=total_movies)
        
        current_page += 1
        
        url = re.sub('pagina=\d+', 'pagina=' + str(current_page), url)
        
        if not all:
            break

    if not all and current_page != total_pages + 1:
        addDir("Next Page >>", url, 23)


def search(category='all'):
    kb = xbmc.Keyboard('', 'Search', False)

    lastSearchPath = os.path.join(common.profile_path, 'search')

    try:
        if os.path.isfile(lastSearchPath):
            with open(lastSearchPath, 'r') as f:
                kb.setDefault(f.read())

    except Exception as e:
        common.log(e)
        pass

    kb.doModal()

    if not kb.isConfirmed():
        sys.exit()

    inputText = kb.getText()

    try:
        with open(lastSearchPath, 'w') as f:
            f.write(inputText)

    except Exception as e:
        common.log(e)
        pass

    if inputText == '':
        xbmcgui.Dialog().ok('Search', 'There is nothing to search.')
        sys.exit()

    results = scraper.getSearchResults(inputText, category)

    total = len(results)

    if total <= 0:
        xbmcgui.Dialog().ok('', 'Error: something went wrong.')
        sys.exit()

    for result in results:
        if result['type'] == 'tvshow':
            mode = 100
            folder = True
        
        elif result['type'] == 'movie':
            mode = 200
            folder = False
        
        addItem(result['name'], result['url'], mode, year=result['year'], folder=folder, totalItems=total)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def recentlyAdded(category):
    results = scraper.getRecentlyAdded(category, int(common.getSetting('limitRecentlyAdded')))

    total = len(results)

    if total <= 0:
        xbmcgui.Dialog().ok('', 'Error: something went wrong.')
        sys.exit()

    for item in results:
        if category == 'tvshows':
            addItem(item['name'], item['url'], 102, season=item['season'], ep_num=item['episode'], folder=False, totalItems=total)
        
        elif category == 'movies':
            addItem(item['name'], item['url'], 200, year=item['year'], folder=False, totalItems=total)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))	


def http_req(url, params={}, autoDetectEncoding=True):
	if params:
		return Net().http_POST(url, params, common.HEADERS, True, autoDetectEncoding).content
	return Net().http_GET(url, common.HEADERS, True, autoDetectEncoding).content


def playTrailer(name,url,thumbnail=''):
    progress = xbmcgui.DialogProgress()
    progress.create('Progress', 'Please wait...')
    
    if re.search('YT_ID:', url):
        yt_id = url.split('YT_ID:')[1]
    else:
        yt_id = re.search(r"<iframe width='595' height='335' src='.+?/embed/(.+?)'", http_req(url))
        yt_id = yt_id.group(1) if yt_id else False

    if not yt_id:
        xbmcgui.Dialog().ok('', 'Error: trailer link not available!')
        sys.exit()

    yt_url = 'http://www.youtube.com/watch?v=' + yt_id
    
    stream = resolvers.resolve(yt_url)

    if not stream:
        sys.exit()

    liz = xbmcgui.ListItem(name, iconImage=thumbnail, thumbnailImage=thumbnail)
    liz.setInfo(type = 'Video', infoLabels = {'title': name})

    xbmc.Player().play(item=stream[0], listitem=liz)

    progress.close()


def playStream(url,title,thumbnail,season='',episode='',ep_name=''):
    src = selectSource(url)

    if not src:
        xbmcgui.Dialog().ok('', 'Error: stream file not available!')
        sys.exit()

    video_url, subtitle_file = src

    win = xbmcgui.Window(10000)
    win.setProperty('990.playing.title', title.lower())
    win.setProperty('990.playing.season', str(season))
    win.setProperty('990.playing.episode', str(episode))
    win.setProperty('990.playing.subtitle', subtitle_file)

    if season and episode:
        title = ('%s %sx%s' % (title, season, episode)).strip()
    
    title = ('%s %s' % (title, ep_name)).strip()

    item = xbmcgui.ListItem(title, iconImage='DefaultVideo.png', thumbnailImage=thumbnail)
    item.setInfo(type = 'Video', infoLabels = {'title': title})
    item.setPath(video_url)

    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return True


def selectSource(url):
    sources = scraper.getStreamSourceMirrors(url)
    
    if not sources:
        xbmcgui.Dialog().ok('', 'Error: video source(s) not available!')
        sys.exit()

    labels = [s['label'] for s in sources]

    heading = ''
    if re.search('filme', url):
        quality = scraper.getMovieQuality(url)
        if quality:
            heading = 'Video Quality: %s' % quality

    dialog = xbmcgui.Dialog()
    index = dialog.select(heading, labels)

    if index == -1:
        sys.exit()

    url = scraper.getStreamMirrorUrl(sources[index]['url'])

    if not url:
        xbmcgui.Dialog().ok('', 'Error: stream mirror not available!')
        sys.exit()

    enableSub = common.addon.getSetting('enableSub') == 'true'
    
    stream = resolvers.resolve(url, enableSub)

    video_url, subtitle_url = stream
    subtitle_file = saveSubtitle(subtitle_url) if subtitle_url else ''

    return (video_url, subtitle_file)


def saveSubtitle(url):
    try:
        filename = url.split('/')[-1]
        filepath = os.path.join(xbmc.translatePath('special://temp'), filename)
        if os.path.exists(filepath):
            os.remove(filepath)
        with open(filepath, 'w') as f:
            f.write(http_req(url, None, False))
        return filepath
    except Exception as e:
        common.log(e)
        pass
    return ''


def addDir(name,url,mode,thumbnail='',folder=True,totalItems=0,listitem=None,params={}):
    global PARAMS

    if not thumbnail:
        thumbnail = 'DefaultFolder.png' if folder else 'DefaultVideo.png'

    if not listitem:
        listitem = xbmcgui.ListItem()
        
        listitem.setLabel(name)
        listitem.setIconImage(thumbnail)
        listitem.setThumbnailImage(thumbnail)
        
        listitem.setInfo(type = 'Video', infoLabels = {'title': name})
        
        listitem.addContextMenuItems([], replaceItems=True)
        
    if PARAMS:
        params.update(PARAMS)

    params['name'] = name
    params['url'] = url
    params['mode'] = mode
    params['thumbnail'] = thumbnail

    empty_keys = [k for k in params if not params[k]]
    for key in empty_keys:
        del params[key]

    u = sys.argv[0] + '?' + urllib.urlencode(params)

    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=listitem,isFolder=folder,totalItems=totalItems)


def addItem(name,url,mode,thumbnail='',year='',season='',ep_num='',ep_name='',folder=True,totalItems=0,meta={}):
    global THUMBNAIL
    global NO_META_COVERS_FOUND

    name = utils.unescape(name, True)
    yearFormat = format_year(year)
    ep_name = utils.unescape(ep_name, True)

    videoType = None
    nextMode = None
    
    if mode == 100:
        videoType = 'tvshow'
        nextMode = 14
        year = yearFormat['start_end']

    elif mode == 101:
        videoType = 'season'
        nextMode = 15

    elif mode in (102, 103):
        videoType = 'episode'
        nextMode = 1
        
    elif mode == 200:
        videoType = 'movie'
        nextMode = 1
        year = yearFormat['start']
    
    if ENABLE_META:
        if videoType == 'tvshow':
            meta = MetaGet.get_meta('tvshow', name)

        elif videoType == 'movie':
            meta = MetaGet.get_meta('movie', name, year=year)

        elif videoType == 'episode' and season and utils.intTryParse(ep_num):
            episodes = ep_num.split('-')
            episode = episodes[0] if (len(episodes) > 1) else ep_num
            meta = MetaGet.get_episode_meta(name, IMDB_ID, int(season), int(episode), episode_title = ep_name)

        if videoType in ('tvshow', 'movie'):
            if not meta['cover_url'] or not meta['backdrop_url']:
                NO_META_COVERS_FOUND.append([name, year])

    display_name = name

    if year:
        display_name = '%s (%s)' % (name, year)
        
    if mode == 102:
        display_name = '%s %sx%s %s' % (name, season, ep_num, ep_name)
        
    elif mode == 103:
        display_name = '%sx%s %s' % (season, ep_num, ep_name)

    display_name = display_name.strip()

    liz = xbmcgui.ListItem()

    if meta:
        thumbnail = meta['cover_url']
        if videoType == 'season':
            thumbnail = meta['cover_url']
            if videoType == 'season' and not meta['cover_url']:
                thumbnail = THUMBNAIL
        liz.setProperty('fanart_image', meta['backdrop_url'])

    liz.setIconImage(thumbnail)
    liz.setThumbnailImage(thumbnail)

    contextMenuItems = []

    if not folder:
        contextMenuItems.append(('Play', 'XBMC.Action(Play)'))
        liz.setProperty('isPlayable', 'true')
        liz.setProperty('resumetime', str(0))
        liz.setProperty('totaltime', str(1))

    infoLabels = {'title': name}

    params = {}
    params['year'] = year
    params['season'] = season
    params['episode'] = ep_num
    params['ep_name'] = ep_name
    params['video_type'] = videoType
    if mode == 100:
        params['tvshowname'] = name

    if meta and videoType in ('tvshow', 'movie'):
        if meta['year'] and not year:
            display_name = '%s (%s)' % (meta['title'], meta['year'])
        params['imdb_id'] = meta['imdb_id']

    if videoType in ('tvshow', 'movie', 'episode') and meta:
        infoLabels = meta

    if videoType == 'movie':
        trailer_url = url
        if meta and meta['trailer_url']:
            trailer_url = u'YT_ID:' + meta['trailer_url']
            trailer_url = utils.unescape(trailer_url)
        trailer_params = {'name': display_name + ' Trailer', 'url': trailer_url, 'mode': 2, 'thumbnail': thumbnail}
        u = sys.argv[0] + '?' + urllib.urlencode(trailer_params)
        if meta and meta['trailer_url']:
            meta['trailer'] = u
        contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % u))

    if meta and videoType in ('tvshow', 'movie', 'episode'):
        contextMenuItems.append(('Show Information', 'XBMC.Action(Info)'))

    liz.setLabel(display_name)
    liz.setInfo(type = 'Video', infoLabels = infoLabels)
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)

    addDir(name, url, nextMode, thumbnail, folder, totalItems, liz, params)


def format_year(str_year):
	year = {'start': '', 'end': '', 'start_end': ''}
	
	str_year = utils.unescape(str_year)
	str_year = str_year.replace('(', '').replace(')', '').strip()
	
	m = re.search(r'(\d{4})-?(\d{4})?', str_year)
	if m:
		year['start'] = m.group(1)
		
		end_year = m.group(2)
		if end_year:
			year['end'] = end_year
		
		year['start_end'] = '%s-%s'% (year['start'], year['end'])
	
	return year


def create_meta_pack():
	pass


class CustomPlayer (xbmc.Player):
    def __init__ (self, axelhelper=None, download_id=None):
        self.axelhelper = axelhelper
        self.download_id = download_id
        self.subtitle_file = ''
        self.title = ''
        self.season = ''
        self.episode = ''
        self.video_type = ''
        
        xbmc.Player.__init__(self)
        
        common.log('Player: Initializing...')

    def play(self, url, listitem, subtitle=''):
        if subtitle:
            self.subtitle_file = subtitle
            self.setSubtitles(self.subtitle_file)
            common.log('Player: Using subtitle file... %s' % self.subtitle_file)
        
        xbmc.Player().play(url, listitem)
        
        common.log('Player: Playing... %s' % url)

    def onPlayBackStarted(self):
        common.log('Player: Playback started')
        self.totalTime = self.getTotalTime()

    def onPlayBackStopped(self):
        playedTime = self.getTime()
        
        if self.download_id:
            self.axelhelper.stop_download(self.download_id)
        
        percentPlayed = int((playedTime / totalTime) * 100)
        
        common.log('Player: current time: ' + str(currentTime) + ' total time: ' + str(totalTime) + ' percent watched: ' + str(percentPlayed))
        
        if (percentPlayed >= 85) and (totalTime > 1):
            #vidname = cache.get('videoname')
            #video = get_video_name(vidname)
            #xbmc.log(addonId, 'Auto-Watch - Setting %s to watched' % video)
            #ChangeWatched(imdbnum, video_type, video['name'], season_num, episode_num, video['year'], watched=7)
            pass
        
        try:
            if os.path.exists(self.subtitle):
                os.remove(self.subtitle)
        
        except Exception as e:
            common.log(e)
            pass

    def onPlayBackEnded(self):
        common.log('Player: Playback completed')
        self.onPlayBackStopped()


if MODE == 0:
    main()
elif MODE == 10:
    tvShowsIndex()
elif MODE == 11:
    getTVShows()
elif MODE == 12:
    getTVShows(filter=NAME)
elif MODE == 14:
    getSeasons(URL)
elif MODE == 15:
    getEpisodes(URL)
elif MODE == 20:
    moviesIndex(URL)
elif MODE == 21:
    moviesIndex(URL,order='year')
elif MODE == 22:
    moviesIndex(URL,order='genre')
elif MODE == 23:
    getMovies(URL)
elif MODE == 24:
    getMovies(URL, True)
elif MODE == 30:
    search()
elif MODE == 31:
    search('tvshows')
elif MODE == 32:
    search('movies')
elif MODE == 40:
    recentlyAdded('tvshows')
elif MODE == 41:
    recentlyAdded('movies')
elif MODE == 1:
    thumbnail = THUMBNAIL
    if TVSHOWTHUMBNAIL and (VIDEO_TYPE == 'tvshow'):
        thumbnail = TVSHOWTHUMBNAIL
    playStream(URL,NAME,thumbnail,SEASON,EPISODE,EP_NAME)
elif MODE == 2:
    playTrailer(NAME,URL,THUMBNAIL)
elif MODE == 95:
    common.addon.openSettings()
elif MODE == 96:
	if utils.clearCache(common.cache_path):
		xbmcgui.Dialog().ok('', 'Cache storage successfully cleared.')
	else:
		xbmcgui.Dialog().ok('', 'Something went wrong.')
elif MODE == 999:
    create_meta_pack()

if MODE in (11, 12, 14, 15, 23, 24):
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

if ENABLE_META and NO_META_COVERS_FOUND:
    common.log('No meta found for:')
    common.log(str(NO_META_COVERS_FOUND))
