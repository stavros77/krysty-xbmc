import os, hashlib, re
from resources.lib.net import Net
import common, utils

CACHE_ENABLE = common.addon.getSetting('enableCache') == 'true'
CACHE_EXPIRE = int(common.addon.getSetting('cacheExpire'))


def urlFilter(url):
	if isinstance(url, unicode):
		url = url.encode('utf-8')
	if not url == '':
		if url.startswith('/'):
			url = url[1:]
		if not url.startswith(common.URLS['base']):
			url = common.URLS['base'] + url
	return url


def cache(url, action, type, data=None, param=None):
    filename = url + type
    if param:
        filename += param
    filename = hashlib.md5(filename).hexdigest()
    filepath = os.path.join(common.cache_path, filename)
    
    if action == 'save':
        utils.save_to_cache(type, data, filepath)
        return
    
    elif action == 'load':
        return utils.load_from_cache(type, filepath, CACHE_EXPIRE)


def _getHtml(url):
    html = ''
    
    if CACHE_ENABLE:
        html = cache(url, 'load', 'string')
    
    if not html:
        html = Net().http_GET(url, common.HEADERS).content
        
        if html and CACHE_ENABLE:
            cache(url, 'save', 'string', html)
    
    return html


def _extract_html_div(html, div_start_string):
    try:
        m = re.search(div_start_string, html, re.DOTALL)
        
        html = html[m.start():]

        div = ''

        i = 0
        for line in html.splitlines():
            div += line.strip()
            m = re.findall(r'<div', line)
            n = re.findall(r'<\/div>', line)
            i += len(m)
            i -= len(n)
            if i == 0:
                break
        
        return div
    
    except Exception as e:
        common.log(e)
        return None


def _ro2en(string):
	dict = {
			'Actiune':		'Action',
			'Animatie':		'Animation',
			'Aventura':		'Adventure',
			'Biografie':	'Biography',
			'Comedie':		'Comedy',
			'Crima':		'Crime',
			'Documentar':	'Documentary',
			'Dragoste':		'Romance',
			'Familie':		'Family',
			'Fantezie':		'Fantasy',
			'Istorie':		'History',
			'Mafie':		'Mafia',
			'Mister':		'Mystery',
			'Razboi':		'War',
			'Sarbatori':	'Holidays',
			'SF':			'Sci-Fi'
	}
	string = string.strip()
	
	if string in dict:
		return dict[string]
	
	return string


def _parseTVShows(html, filter=None):
    tvshows = []

    try:
        soup = common.initBeautifulSoup(html).find('div', {'id': 'tab1'})
        
        if not filter:
            results = soup.findAll('a', {'class': 'link'})
        else:
            results = soup.findAll('a', {'class': 'link'}, text = re.compile(r'^' + filter + '.+?$', re.IGNORECASE))
        
        for a in results:
            tvshow = {}
            tvshow['name'] = a.text
            tvshow['url'] = urlFilter(a['href'])
            tvshow['year'] = a.nextSibling
            tvshows.append(tvshow)
    
    except Exception as e:
        common.log(e)
        pass

    return tvshows
    

def _parseEpisodes(html, season):
    episodes = []

    try:
        soup = common.initBeautifulSoup(html).find('div', {'id': 'content'})
        
        lst = re.split(r'<img alt="Sezonul \d+"', str(soup))
        lst.pop(0)
        
        soup = common.initBeautifulSoup(lst[int(season)-1])
        
        a_tags = soup.findAll('a', href=re.compile('seriale2'))
        
        for a in a_tags:
            ep_n = a.parent.parent.div.text
            m = re.search(r'Sezonul \d+, Episodul (\d+)', ep_n)
            ep_num = m.group(1) if m else ''
            
            ep_name = a.text
            if re.search(r'Episodul [\d-]+', ep_name):
                ep_name = ''

            episode = {}
            episode['url'] = urlFilter(a['href'])
            episode['season'] = season
            episode['number'] = ep_num
            episode['name'] = ep_name
            episodes.append(episode)

    except Exception as e:
        common.log(e)

    return episodes


def _parseMovies(html):
    movies = []

    try:
        results = re.findall(r"<a href='(filme.+?)'.+? class='link'>(.+?)</a>.+?Aparitie: ?(.+?)[<br/>]*Gen", html, re.DOTALL)

        for url, name, year in results:
            movie = {}
            movie['url'] = urlFilter(url)
            movie['name'] = name
            movie['year'] = year
            movies.append(movie)

    except Exception as e:
        common.log(e)

    return movies


def _get(url, type, param=None):
    lst = []

    if CACHE_ENABLE:
        cache_data = cache(url, 'load', 'json', param=param)
        
        if cache_data:
            lst = cache_data

    if not lst:
        html = _getHtml(url)
        
        if type == 'tvshows':
            lst = _parseTVShows(html, param)
        
        elif type == 'episodes':
            lst = _parseEpisodes(html, param)
        
        elif type == 'movies':
            lst = _parseMovies(html)
        
        if lst and CACHE_ENABLE:
            cache(url, 'save', 'json', lst, param)

    return lst


def getTVShows(filter=False):
    return _get(common.URLS['tvshows'], 'tvshows', filter)


def getSeasons(url):
    html = _getHtml(url)
    
    m = re.findall(r"<img src='.+?' alt='Sezonul (\d+)'>", html)
    
    return len(m)


def getEpisodes(url, season):
    return _get(url, 'episodes', season)


def getMovies(url):
    return _get(url, 'movies')


def getRecentlyAdded(category, resultsLimit):
    lst = []

    try:
        html = Net().http_GET(common.URLS['base'], common.HEADERS).content

        soup = common.initBeautifulSoup(html).findAll('div', {'id': 'tab1'})

        if category == 'tvshows':
            soup = soup[0]
            param = 'seriale'

        elif category == 'movies':
            soup = soup[1]
            param = 'filme'

        results = soup.findAll('a', href=re.compile(param), limit=resultsLimit)

        for a in results:
            ep_year = a.parent.parent.findAll('div')[1].text.strip()
            
            item = {}
            item['name'] = a.text
            item['url'] = urlFilter(a['href'])
            
            if category == 'tvshows':
                eps = re.search(r'S(\d+)E(\d+-?\d*)', ep_year)
                
                season = eps.group(1) if eps else ''
                episode = eps.group(2) if eps else ''
                
                item['season'] = season
                item['episode'] = episode
            
            elif category == 'movies':
                item['year'] = ep_year
            
            lst.append(item)

    except Exception as e:
        common.log(e)

    return lst


def getTotalPages(url):
    pages = 1
    try:
        html = _getHtml(url)
        soup = common.initBeautifulSoup(html)
        a = soup.find('div', {'id': 'numarpagini'}).findAll('a', text=re.compile('\d+'))
        pages = max([int(x.text) for x in a])
    except Exception as e:
        common.log(e)
    return pages


def getVideoCategories(type):
    categories = []

    try:
        url = common.URLS['movies']
        
        html = _getHtml(url)
        
        soup = common.initBeautifulSoup(html)
        
        if type == 'year':
            results = soup.findAll('div', {'id': 'filtre'})[1].findAll('a', attrs = {'class': None})
        
        elif type == 'genre':
            results = soup.find('div', {'id': 'filtre'}).findAll('a', attrs = {'class': None})
        
        for a in results:
            name = a.text
            if type == 'genre':
                name = _ro2en(name)
            
            category = {}
            category['name'] = name
            category['url'] = url + a['href']
            categories.append(category)

    except Exception as e:
        common.log(e)

    return categories


def getStreamSourceMirrors(url):
    sources = []

    src_alias = {
        'fast': 'superweb',
        '180u': '180upload',
        'xvid': 'xvidstage',
        'vidx': 'vidxden',
        'vidb': 'vidbux'
    }

    try:
        html = _getHtml(url)

        m = re.findall(r"<a class='link' href='(player.+?)'", html)

        links = []
        for a in m:
            if a not in links:
                links.append(a)

        for i in range(len(links)):
            label = 'Stream Source: Mirror #%s' % str(i+1)
            m = re.search(r'\d+-s([^-\.]+)', links[i])
            if m:
                src_name = m.group(1)
                if src_name in src_alias:
                    src_name = src_alias[src_name]
                label += ' ' + src_name
            sources.append({'label': label, 'url': urlFilter(links[i])})

    except Exception as e:
        common.log(e)

    return sources


def getStreamMirrorUrl(url):
    try:
        html = _getHtml(url)

        playerdiv = _extract_html_div(html, r"<div class='player.+?'")

        s = re.search(r"<a href='(http:\/\/(?:www\.)?.+?)'>", playerdiv).group(1)

        return s[s.rfind('http'):]

    except Exception as e:
        common.log(e)
        return None


def getMovieQuality(url):
    try:
        html = _getHtml(url)

        if re.search('filme', url):
            n = re.search(r'Calitate film: nota <b>(.+?)</b>', html)
            if n:
                return n.group(1)

    except Exception as e:
        common.log(e)
        return ''


def getSearchResults(text, category='all'):
    results = []

    try:
        html = Net().http_POST(common.URLS['search'], {'kw': text}, common.HEADERS).content

        if category == 'tvshows':
            param = 'seriale'

        elif category == 'movies':
            param = 'filme'

        if category == 'all':
            m = re.findall(r"<a href='(.+?)'.+?id='rest'>(.+?)<div", html)
        else:
            m = re.findall(r"<a href='(" + param + ".+?)'.+?id='rest'>(.+?)<div", html)

        for link, name in m:
            year_pattern = re.compile(r'\(.+?\)')
            n = year_pattern.search(name)
                
            name = re.sub(year_pattern, '', name).strip()
            year = n.group(0) if n else ''
            
            if re.search(r'seriale', link):
                type = 'tvshow'
                
            elif re.search(r'filme', link):
                type = 'movie'
            
            item = {}
            item['type'] = type
            item['name'] = name
            item['year'] = year
            item['url'] = urlFilter(link)
            results.append(item)

    except Exception as e:
        common.log(e)

    return results
