import os, re, random, traceback
import urllib, urllib2
import common, log_utils
from cookielib import LWPCookieJar
from resources.lib.parsedom import parseDOM
from resources.lib import b64
from resources.lib import phpserialize


LOGIN_COOKIE_FILE = os.path.join(common.profile_path, 'login_cookie')


class NoRedirection(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response


def http_req(url, data=None, headers={}, cookie=None):
    if cookie:
        cj = LWPCookieJar()
        
        if os.path.isfile(cookie):
            cj.load(cookie, ignore_discard=True)
        
        opener = urllib2.build_opener(NoRedirection, urllib2.HTTPCookieProcessor(cj))
        urllib2.install_opener(opener)
    
    if data is not None:
        data = urllib.urlencode(data)
        req = urllib2.Request(url, data)
    else:
        req = urllib2.Request(url)
    
    for k, v in common.HEADERS.items():
        req.add_header(k, v)
    
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    
    conn = urllib2.urlopen(req)
    
    if cookie:
        cj.save(cookie, ignore_discard=True)
    
    return conn


_HEADERS = common.HEADERS
_HEADERS['Host'] = common.URLS['host']
_HEADERS['Upgrade-Insecure-Requests'] = '1'
_HEADERS['Referer'] = common.URLS['login']


def isLoggedIn():
    if not os.path.isfile(LOGIN_COOKIE_FILE):
        return False

    try:
        conn = http_req(common.URLS['account'], {}, _HEADERS, LOGIN_COOKIE_FILE)
        ret_code = conn.code
        conn.close()
        
        if not ret_code == 302:
            return True
        
    except:
        log_utils.log(traceback.print_exc())

    return False


def doLogin(email, password):
    try:
        data = {
            'email': email,
            'password': password,
            'remember': '1',
            'Submit': 'Login',
            'action': 'process'
        }
        conn = http_req(common.URLS['login'], data, _HEADERS, LOGIN_COOKIE_FILE)
        ret_code = conn.code
        conn.close()

        if ret_code == 302:
            return True

    except:
        log_utils.log(traceback.print_exc())

    return False


def getTVChannelsList():
    lst = []
    
    try:
        conn = http_req(common.URLS['account'], {}, _HEADERS, LOGIN_COOKIE_FILE)
        html = conn.read()
        conn.close()
        
        ul = parseDOM(html, 'ul', attrs={'class': 'sc_menu'})[0]
        
        results = re.findall(r'playFlowRtmpE\(\'(.+?)\'\).+?<img src="(.+?)".+?<a href.+?>(.+?)<\/a>', ul)
        
        for id, img, name in results:
            tv = {}
            tv['id'] = id.strip().encode('utf-8')
            tv['img'] = img.strip().encode('utf-8')
            tv['name'] = name.strip().encode('utf-8')
            lst.append(tv)
    
    except:
        log_utils.log(traceback.print_exc())
    
    return lst


def getStreamUrl(stream_id):
    try:
        u = common.URLS['strm_info'] % (stream_id, str(random.random()))
        conn = http_req(u, headers=common.HEADERS)
        p = conn.read()
        conn.close()
        
        if p == '1':
            conn = http_req(u, {}, headers=common.HEADERS)
            data = conn.read()
            conn.close()
            
            data = b64.decode(data)
            data = phpserialize.loads(data)
            
            rtmp = '%s://%s/%s/%s' % (data['stream_type'], data['server'], data['app'], data['stream'])
            
            return rtmp
    except:
        log_utils.log(traceback.print_exc())
    
    return None