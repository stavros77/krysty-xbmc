import uuid, hashlib
from resources.lib import pyaes, b64

_pwd = str(uuid.uuid1()).split('-')[-1]
_key = hashlib.md5(_pwd).digest()

def encrypt(plaintext):
    return b64.encode(pyaes.AESModeOfOperationCTR(_key).encrypt(plaintext))

def decrypt(encryptedtext):
    return pyaes.AESModeOfOperationCTR(_key).decrypt(b64.decode(encryptedtext))